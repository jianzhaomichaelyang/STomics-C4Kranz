
proname=cortex
data=../../cortex_02.rds

for root in 6; do

mkdir ${proname}_root${root}
cd ${proname}_root${root}

cat>monocle3_v1.R<<'EOF'
library(getopt)
arg <- matrix(c("input", "i","1","character","input file1",
                "node", "n","1","character","cluster contains node",
                "plot.marker","f","1","logical","plot marker genes or not",
                "input.marker","g","1","character","marker gene list for plot",
                "marker.col","k","1","character","colnames of marker genes in marker tabel",
                "pro_name","p","1","character","proname for file to save"
                ),byrow=T,ncol=5)

opt = getopt(arg)

if(FALSE)
{
opt<-list()
opt$input<-'/hwfssz1/ST_EARTH/P20Z10200N0035/USER/zhaocaiyao/C3_C4/sorghum/stem_scRNA/test1_1st.data/harmony_try4.soupx_gene500_8000_lambda1/data.RDS'
opt$node<- 9
opt$pro_name <- "sorghum"
}

library(Seurat)
library(monocle3)
library(Biobase)
library(knitr)
library(reshape2)
library(ggplot2)
library(plyr)
library(dplyr)
library(reshape2)
library(scales)
library(RColorBrewer)

## step 0: prepare cds object
md <- readRDS(opt$input)
expression_matrix <- md@assays$RNA@counts
cell_meta <- md@meta.data
gene_meta <- data.frame(gene_short_name = row.names(expression_matrix), row.names = row.names(expression_matrix))

cds <- new_cell_data_set(as(expression_matrix,"sparseMatrix"), cell_meta = cell_meta, gene_meta = gene_meta)
cds <- cds[,Matrix::colSums(exprs(cds)) != 0]

## Step 1: Normalize and pre-process the data
cds <- preprocess_cds(cds, num_dim = 100)
cds <- align_cds(cds, alignment_group = "batch")

## Step 3: Reduce the dimensions using UMAP
cds <- reduce_dimension(cds)
cds <- cluster_cells(cds,reduction_method="UMAP")
name1 <- paste("01", opt$pro_name, "monocle3_cluster.pdf", sep = "_")
pdf(name1, width = 16, height = 8)
plot1 <- plot_cells(cds, label_groups_by_cluster = F, color_cells_by="seurat_clusters")
plot2 <- plot_cells(cds, label_groups_by_cluster = F, color_cells_by="partition")
plot1+plot2
dev.off()

## Step 4: Learn a graph
cds <- learn_graph(cds)
name2 <- paste("02", opt$pro_name, "monocle3_graph.branch.pdf", sep = "_")
pdf(name2, width = 17, height = 8)
plot3 <- plot_cells(cds, color_cells_by = "partition",label_groups_by_cluster=FALSE,label_leaves=TRUE,label_branch_points=TRUE,label_cell_groups = FALSE)
plot4 <- plot_cells(cds,color_cells_by="seurat_clusters",label_groups_by_cluster=FALSE,label_leaves=TRUE,label_branch_points=TRUE,label_cell_groups = FALSE)
print(plot3+plot4)
dev.off()

name3 <- paste("03",opt$pro_name, "monocle3_graph.branch.without.label.pdf", sep = "_")
pdf(name3, width = 17, height = 8)
plot5 <- plot_cells(cds, color_cells_by = "partition",label_groups_by_cluster=FALSE,label_leaves=FALSE,label_branch_points=FALSE,label_cell_groups = FALSE)
plot6 <- plot_cells(cds,color_cells_by="seurat_clusters",label_groups_by_cluster=FALSE,label_leaves=FALSE,label_branch_points=FALSE,label_cell_groups = FALSE)
plot5+plot6
dev.off()


##Order the cells in pseudotime

get_earliest_principal_node <- function(cds, time_bin=opt$node){

  cell_ids <- which(colData(cds)[,"seurat_clusters"] == time_bin)

  closest_vertex <-
    cds@principal_graph_aux[["UMAP"]]$pr_graph_cell_proj_closest_vertex
  closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
  root_pr_nodes <-
    igraph::V(principal_graph(cds)[["UMAP"]])$name[as.numeric(names
      (which.max(table(closest_vertex[cell_ids,]))))]

  root_pr_nodes
}

cds = order_cells(cds, root_pr_nodes=get_earliest_principal_node(cds))


name4 <- paste("04", opt$pro_name, "monocle3_trajectorise_set_root.pdf", sep = "_")
pdf(name4, width = 16, height = 5)
plot8 <- plot_cells(cds, label_groups_by_cluster = T, color_cells_by="old.ident", label_leaves=FALSE,label_branch_points=FALSE,label_cell_groups=T)
plot7 <- plot_cells(cds,
           color_cells_by = "pseudotime",
                   cell_size = 1,
           label_cell_groups=FALSE,
           label_leaves=FALSE,
           label_branch_points=FALSE,
           graph_label_size=1.5)

plot1+plot8+plot7
dev.off()


pseudotime <- pseudotime(cds, reduction_method = 'UMAP')
md@meta.data$pseudotime<-pseudotime

name5 <- paste("04", opt$pro_name, "monocle3.cds.RDS", sep = "_")
name6 <- paste("05", opt$pro_name, "data.pseudotime.RDS", sep = "_")
saveRDS(cds, name5)
saveRDS(md, name6)

#pdf("seurat.umap.pseudotime.pdf", width = 16, height=8)
#plot1 <- DimPlot(object = md, reduction = "umap", label = T,pt.size=0.5,group.by = "ident")
#plot1.1 <- FeaturePlot(md, features = "pseudotime")
#print(plot1+plot1.1)
#dev.off()

if(opt$plot.marker){
input.marker <- read.csv(opt$input.marker,header = T)


pdf(paste0(opt$pro_name, "input.marker.trajectory.plot.pdf"), width = 8, height = 5)
genes <- input.marker[,opt$marker.col]
genes <- genes[which(genes %in% rownames(cds))]
p1 <- list()
for (i in 1:length(genes)){

  p1[[i]] <- plot_cells(cds,
                        genes=genes[i],
                        label_cell_groups=FALSE,
                        show_trajectory_graph=FALSE ,cell_size=1)+ scale_color_gradient(low="grey", high="blue")

}
print(p1)

dev.off()

}

EOF


cat>monocle3_v1.sh<<EOF
/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/zhongliyuan/miniconda3/envs/R4.1/bin/Rscript \
monocle3_v1.R \
-i ${data} \
-n ${root} \
-p ${proname}
EOF

qsub -clear -cwd -q st.q -P P20Z10200N0035 -l vf=20g,num_proc=1 -binding linear:1 monocle3_v1.sh

cd ..
done
