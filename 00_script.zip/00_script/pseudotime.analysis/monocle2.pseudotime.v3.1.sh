
cat>monocle2.R<<'EOF'
library(getopt)
arg <- matrix(c("input", "i","1","character","input file1",
                "ordering.genes","o","1","character","input ordering genes",
                "set.root", "r","1","logical","set root or not",
                "root.cluster","c","1","character","set root of cluster",
                "input.marker","g","1","character","marker gene list for plot",
                "marker.col","k","1","character","colnames of marker genes in marker tabel",
                "differential","d","1","logical","find marker gene to order plot",
                "proname","n","1","character","proname for saving file"
                ),byrow=T,ncol=5)
opt = getopt(arg)
if (is.null(opt$proname)){
        opt$proname <- "kranz"
}
if (is.null(opt$set.root)){
        opt$set.root <- F
}
if (is.null(opt$root.cluster)){
        opt$root.cluster <- "na"
}
if(is.null(opt$differential)){
        opt$differential <- F
}


library(Seurat)
library(dplyr)
library(monocle)
library(RColorBrewer)

print("Step1 prepare data and store Data in a CellDataSet")
print("loading data")
seurat.rds <- readRDS(opt$input)
##data matrix
print("data matrix")
data_matrix <- as.matrix(seurat.rds@assays[["RNA"]]@counts)
#data_matrix <- as.matrix(data.all)

##gene feature
print("gene feature")
feature_ann <- data.frame(gene_id=rownames(data_matrix),gene_short_name=rownames(data_matrix))
rownames(feature_ann) <- rownames(data_matrix)
data_fd <- new("AnnotatedDataFrame", data = feature_ann)

##cell feature
print("cell feature")
m.data <- seurat.rds@meta.data
data_pd <- new("AnnotatedDataFrame", data = m.data)

print("creat new data of cds")
data.cds <- newCellDataSet(data_matrix,phenoData =data_pd,featureData =data_fd,expressionFamily=negbinomial.size())
data.cds <- estimateSizeFactors(data.cds)
data.cds <- estimateDispersions(data.cds)



##select the differentially expressed genes to be used below
print("differentialGeneTest")
#if(opt$differential){
diff_test_res <- differentialGeneTest(data.cds, fullModelFormulaStr = "~seurat_clusters")
write.csv(diff_test_res, paste0(opt$proname, "marker.genes.group.by.seurat.cluster.csv"))
print("ordering_genes")
ordering_genes1 <- row.names(subset(diff_test_res, qval < 0.01))
#} else {disp_table <- dispersionTable(data.cds)
#       print("ordering_genes")
#       ordering_genes <- subset(disp_table, mean_expression >= 0.1)
#       }
#markers <- read.csv(opt$ordering.genes, header = T)
#colnames(diff_test_res) <- "gene"
#ordering_genes <- unique(markers$gene)

disp_table <- dispersionTable(data.cds)
ordering_genes2 <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)[,"gene_id"]

ordering_genes <- intersect(ordering_genes1, ordering_genes2)

print("setOrderingFilter")
data.cds <- setOrderingFilter(data.cds, ordering_genes)
print("plot_ordering_genes")
pdf(paste(opt$proname, "00.plot_ordering_genes.pdf", sep = "_"))
plot_ordering_genes(data.cds)
dev.off()

##rduce data dimensionality
print("reduceDimension")
data.cds <- reduceDimension(data.cds,
        max_components = 2,
        reduction_method = 'DDRTree',
        residualModelFormulaStr = "~batch"
        )

#color plot
print("colorRampPalette")
getPalette <- colorRampPalette(brewer.pal(9, "Set1"))
###set the root of trajectory
GM_state <- function(cds, root){
  if (length(unique(pData(cds)$State)) > 1){
    T0_counts <- table(pData(cds)$State, pData(cds)$seurat_clusters)[,root]
    return(as.numeric(names(T0_counts)[which
          (T0_counts == max(T0_counts))]))
  } else {
    return (1)
  }
}

##ordering cell in default way
print("ordering Cells")
data.cds <- orderCells(data.cds, num_paths = 3, reverse=T)
if(opt$set.root){
data.cds <- orderCells(data.cds, num_paths = 3, root_state = GM_state(data.cds, opt$root.cluster))
}
saveRDS(data.cds, paste0(opt$proname, ".01.trajectory.cds"))

pdf(paste(opt$proname,"set.root", opt$root.cluster, "02.trajectory.pdf", sep = "_"), width = 8, height = 5)
plot(plot_cell_trajectory(data.cds, show_cell_names = F, color_by = "Pseudotime")+scale_color_viridis_c())
plot(plot_cell_trajectory(data.cds, show_cell_names = F, color_by = "State")+scale_color_manual(values = getPalette(length(unique(data.cds@phenoData@data[,"State"])))))
plot(plot_cell_trajectory(data.cds, show_cell_names = F, color_by = "seurat_clusters") +scale_color_manual(values = getPalette(length(unique(data.cds@phenoData@data[,"seurat_clusters"])))))
plot(plot_cell_trajectory(data.cds, show_cell_names = F, color_by = "celltype") +scale_color_manual(values = getPalette(length(unique(data.cds@phenoData@data[,"celltype"])))))

dev.off()


#saveRDS(data.cds, paste0(opt$proname, ".trajectory.cds"))
input.list <- read.csv(opt$input.marker, header = T)
input.marker <- unique(input.list[,opt$marker.col])

pdf(paste0(opt$proname, "_03.input.marker.trajectory.plot.pdf"), width = 8, height = 5)
for (i in 1:length(input.marker)){
plot(plot_cell_trajectory(data.cds,markers = input.marker[i], use_color_gradient = TRUE,show_cell_names = F)+scale_color_viridis_c())

}
dev.off()


print("test different genes by state")
diff_test_state <- differentialGeneTest(data.cds, fullModelFormulaStr = "~State")
write.csv(diff_test_state, paste0(opt$proname, "marker.genes.by.state.csv"))
#diff_test_state %>% group_by(state) %>% top_n(diff_test_state, n = 10, wt = qval) -> top10_state
#pdf(paste0(opt$proname,"state_different_markers.pdf"),width = 8, height = 5)
#for (i in 1:length(rownames(top10_state))){
#plot(plot_cell_trajectory(data.cds,markers = top10_state[i,'gene_short_name'], use_color_gradient = TRUE,show_cell_names = F)+scale_color_viridis_c())
#}

#dev.off()


print("test different genes along pseudotime")
diff_test_ps <- differentialGeneTest(data.cds, fullModelFormulaStr = "~sm.ns(Pseudotime)")
write.csv(diff_test_ps, paste0(opt$proname, "marker.genes.by.pseudotime.csv"))

sig_gene_names.ps <- subset(diff_test_ps, qval < 0.5)[,"gene_short_name"]
pdf(paste0(opt$proname, ".pseudotime.marker.heatmap.pdf"), height = 24, width = 16)
plot_pseudotime_heatmap(data.cds[sig_gene_names.ps,],
                num_clusters = 3,
                cores = 1,
                show_rownames = T)
dev.off()

####   Analyzing Branches in Single-Cell Trajectories
BEAM_res <- BEAM(data.cds, branch_point = 1, cores = 1)
write.csv(BEAM_res, paste0(opt$proname, ".branch.allgenes.csv"))
BEAM_res <- BEAM_res[order(BEAM_res$qval),]
BEAM_res <- BEAM_res[,c("gene_short_name", "pval", "qval")]
pdf(paste0(opt$proname, ".branch.markers.heatmap.pdf"))
plot_genes_branched_heatmap(data.cds[row.names(subset(BEAM_res,
                                          qval < 0.05)),],
                                          branch_point = 1,
                                          num_clusters = 3,
                                          cores = 1,
                                          use_gene_short_name = T,
                                          show_rownames = T)

dev.off()

plot_b <- plot_genes_branched_heatmap(data.cds[row.names(subset(BEAM_res,
                                          qval < 0.05)),],
                                          branch_point = 1,
                                          num_clusters = 3,
                                          cores = 1,
                                          use_gene_short_name = T,
                                          show_rownames = T, return_heatmap = T)

branch.m <- plot_b$annotation_row
write.csv(branch.m, paste0(opt$proname, ".branch.markers.csv"))

EOF

cat>monocle2.sh<<EOF
/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/zhongliyuan/miniconda3/envs/R4.1/bin/Rscript \
monocle2.R \
-i ../sc_vein_02.sc_BS.rds \
-r T -c 3 \
-n sc_vein \
-k maize_gene_ID \
-g /hwfssz1/ST_EARTH/P20Z10200N0035/USER/zhaocaiyao/C3_C4/marker_genes/grass_marker_genes.csv
EOF

qsub -clear -cwd -q st.q -P P20Z10200N0035 -l vf=10g,num_proc=1 -binding linear:1 monocle2.sh
