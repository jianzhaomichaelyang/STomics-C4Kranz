

pseudokranz=maize_C3_5BSmature_center_dip_newxy.csv





cat>>Loop_GeneDis.v1.pl<<'EOF'
#!/usr/bin/perl -w
use strict;
use Getopt::Long;


#https://www.cnblogs.com/knowboke/articles/11318496.html
#use List::MoreUtils qw(uniq);

my ($split,$outdir,$TMP);
my ($Target,$Tlist);
my ($multi,$Test);
my $verbose;
my $AddInfo;
my ($Label_DNB_Xn,$Label_DNB_Yn);
my $Loop_Method;
my ($Xmid,$Ymid);
GetOptions(
        "split:i"       =>      \$split,
        "o:s"           =>      \$outdir,
        "TMP:s"         =>      \$TMP,

        "Target:s"      =>      \$Target,
        "Tlist:s"       =>      \$Tlist,

        "multi:f"       =>      \$multi,
        "Test"          =>      \$Test,

        "verbose"       =>      \$verbose,

        "AddInfo:s"     =>      \$AddInfo,

        "LDNB_xN:i"     =>      \$Label_DNB_Xn,
        "LDNB_yN:i"     =>      \$Label_DNB_Yn,

        "LM:s"          =>      \$Loop_Method,

        "Xmid:i"        =>      \$Xmid,
        "Ymid:i"        =>      \$Ymid,
);
$split ||= 3;

#$Label_DNB_Xn ||= 3;
#$Label_DNB_Yn ||= 3;

$Loop_Method ||= "mean";

$outdir ||= "./";
$TMP ||= "tmp";
-e $outdir || `mkdir -p $outdir`;

$multi ||= 1.0;

$Xmid ||= 0;
$Ymid ||= 0;

my %T;
if($Target){
        my @A = split /\,/,$Target;
        foreach my $a(@A){
                $T{$a} = 1;
        }
}

if($Tlist){
        open IN,$Tlist;
        while(<IN>){
                chomp;
                my @l = split;
                my $a = $l[0];
                $T{$a} = 1;
        }
        close IN;
}

@ARGV || die "Usage:perl $0 <txt>\n";

my $txt = shift;

my (%GENE,%LABEL,%DNB);
open IN,$txt;
while(<IN>){
        chomp;
#       /^geneID/ && next;

#geneID  x       y       MIDCount        ExonCount       label
#
#       chomp(my @l = split /\t/);
#       my ($geneID,$x,$y,$MIDCount,$ExonCount,$label) = @l[0..5];

#       "","geneID","x","y","MIDCount","ExonCount","label","full","kranz_x","kranz_y","dip_x","dip_y","new.x","new.y"
#
        s/\"//g;
        /^\,geneID/ && next;
        chomp(my @l = split /\,/);
        my ($geneID,$x,$y,$MIDCount,$ExonCount,$label) = @l[1,12,13,4,5,6];


        if($Target || $Tlist){
                $T{$label} || next;
        }
        push @{$LABEL{$label}{x}},$x;
        push @{$LABEL{$label}{y}},$y;
        $GENE{$label}{$geneID}{$x}{$y} = $MIDCount;
        $DNB{$label}{$x}{$y} = 1;
}
close IN;

if($AddInfo){
        open AI,">$AddInfo";
        print AI "geneID\tx\ty\tMIDCount\tlabel\tLCx\tLCy\tLCd\tLoopN\n";
}
foreach my $label(keys %GENE){
        my @X = @{$LABEL{$label}{x}};
        my @Y = @{$LABEL{$label}{y}};
        @X = sort {$a <=> $b} @X;
        @Y = sort {$a <=> $b} @Y;

        my %X_hash = map { $_, 1 } @X;
        my $Xn = keys %X_hash;
        my %Y_hash = map { $_, 1 } @Y;
        my $Yn = keys %Y_hash;
        $Label_DNB_Xn && ($Xn >= $Label_DNB_Xn || next);
        $Label_DNB_Yn && ($Yn >= $Label_DNB_Yn || next);

        my ($Xmin,$Xmax) = @X[0,-1];
        my ($Ymin,$Ymax) = @Y[0,-1];

=pod
        my ($Xmid,$Ymid);
        if($Loop_Method =~ /mean/i){
                $Xmid = sprintf("%.4f",$Xmin + 0.5*($Xmax - $Xmin));
                $Ymid = sprintf("%.4f",$Ymin + 0.5*($Ymax - $Ymin));
        }elsif($Loop_Method =~ /median/i){
                #https://stackoverflow.com/questions/5119034/using-perl-to-find-median-mode-standard-deviation
                my $mid = int @X/2;
                if(@X % 2){
                        ($Xmid,$Ymid) = ($X[$mid],$Y[$mid]);
                }else{
                        ($Xmid,$Ymid) = (0.5*($X[$mid-1]+$X[$mid]),0.5*($Y[$mid-1]+$Y[$mid]));
                }
        }
#       print "$Xmin,$Xmax,$Ymin,$Ymax,\t$Xmid,$Ymid\n";exit;
=cut

        my $loop_r = 0.5*sqrt(($Xmax - $Xmin)**2 + ($Ymax - $Ymin)**2);
        my $ave_r = $loop_r/$split;
#       print "$loop_r\t$ave_r\n";exit;
        $ave_r || die "$label\t$loop_r\t$ave_r\n";

        #dnb number for each loop
        my %LOOP_DNB_N;
        foreach my $x(sort {$a <=> $b} keys %{$DNB{$label}}){
                foreach my $y(sort {$a <=> $b} keys %{$DNB{$label}{$x}}){
                        my $point_d = sqrt(($x - $Xmid)**2 + ($y - $Ymid)**2);
                        my $loop_n = int($point_d / $ave_r);
                        $LOOP_DNB_N{$loop_n}++;
                }
        }

        foreach my $geneID(keys %{$GENE{$label}}){
                my (%GENE_MID_N,%GENE_DNB_N);
                foreach my $x(sort {$a <=> $b} keys %{$GENE{$label}{$geneID}}){
                        foreach my $y(sort {$a <=> $b} keys %{$GENE{$label}{$geneID}{$x}}){
                                my $point_d = sprintf("%.4f",sqrt(($x - $Xmid)**2 + ($y - $Ymid)**2));
                                my $loop_n = int($point_d / $ave_r);
#                               print "$point_d\t$ave_r\t$loop_n\n";exit;

                                my $MIDCount = $GENE{$label}{$geneID}{$x}{$y};
                                $GENE_MID_N{$loop_n} += $MIDCount;
                                $GENE_DNB_N{$loop_n} ++;

#                              geneID  x       y       MIDCount        ExonCount       label
                               if($AddInfo){
                                        print AI "$geneID\t$x\t$y\t$MIDCount\t$label\t$Xmid\t$Ymid\t$point_d\t$loop_n\n";
                                }
                        }
                }
                print "$label\t$geneID\t";

                my $str;

#               foreach my $loop_n(sort {$a <=> $b} keys %GENE_MID_N){
                foreach my $loop_n(0..$split-1){
                        $GENE_MID_N{$loop_n} ||= 0;
                        $LOOP_DNB_N{$loop_n} ||= 0;
                        $GENE_DNB_N{$loop_n} ||= 0;

                        my $gene_mid_n = $GENE_MID_N{$loop_n};
                        my $loop_dnb_n = $LOOP_DNB_N{$loop_n};
                        my $gene_dnb_n = $GENE_DNB_N{$loop_n};

                        my $gene_mid_n_ave = $loop_dnb_n == 0 ?  "0.0000" : sprintf("%.4f",$multi*$gene_mid_n/$loop_dnb_n);

                        if($verbose){
                                print "$loop_n:$gene_mid_n:$gene_dnb_n:$loop_dnb_n:$gene_mid_n_ave\t";
                        }else{
#                               print "$loop_n:$gene_mid_n_ave\t";
                                print "$gene_mid_n_ave\t";
                        }
                        $str .= "$gene_mid_n_ave,";
                }

                $str =~ s/,$//;
                my $p;
                if($Test){
                        $p = CHISQ_TEST($str);
                }
                $p ||= "NA";

                print "$p\n";
        }
}

if($AddInfo){close AI;}

sub CHISQ_TEST
{
        my $str = shift @_;
        my @s = split /\,/,$str;
        my $n = @s;
        my $sum = 0;
        foreach my $v(@s){
                $sum += $v;
        }
        my $ave = sprintf("%.4f",$sum/$n);

        my $Bv;
        foreach my $v(@s){
                $Bv .= "$ave,";
        }
        $Bv =~ s/,$//;

        my $Av = $str;

open R,">$outdir/$TMP.R";
print R "
library(tidyr)
library(knitr)

A <-c($Av)
B <-c($Bv)

c <- rbind(A,B)
kable(c)
chisq.test(c)
";
close R;

        my $Rinfo = `/hwfssz4/BC_PUB/Software/03.Soft_ALL/R-3.5.1/bin/Rscript $outdir/$TMP.R`;
        my $pvalue = $1 if $Rinfo =~ /p-value\s+\S+\s+(\S+)/;
        return $pvalue;
}


=pod
#Test1
x <- c(1,2,1,1,2,1,1,1,1,1)
y <- c(1.1,1.3,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2)
ks.test(x,y)
#ks.test(x,'punif')


#Test2
A <- c(0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1)
#A <- c(0.11,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.09)
#.libPaths("/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/wangfang/02.software/miniconda3/envs/R_4.1/lib/R/library")
source('/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/wangfang/02.software/miniconda3/envs/R_4.1/lib/R/library/detpack/testing.R')
chi2testuniform(A, 0.05)


#Test3
library(tidyr)
library(knitr)

A <-c(0.00,0.00,2.00,1.50,1.00,1.50,0.00,0.00,1.00,0.00)
B <-c(0.70,0.70,0.70,0.70,0.70,0.70,0.70,0.70,0.70,0.70)

# a * 10, p-value < 0.05
#A <- c(0,0,20,15,10,15,0,0,10,0)
#B <- c(7,7,7,7,7,7,7,7,7,7)

c <- rbind(A,B)
kable(c)
chisq.test(c)

EOF

cat>>Loop_GeneStat.pl<<'EOF'

#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my $multi;
my $Test;
GetOptions(
        "multi:f"       =>      \$multi,
        "Test"          =>      \$Test,
);
$multi ||= 1.0;

@ARGV || die "Usage:perl $0 <txt>\n";

my $txt = shift;

my (%LABEL,%GENE);

open IN,$txt;
while(<IN>){
        chomp;
        my @l = split;
        my ($label,$gene) = @l[0,1];
        $LABEL{$label} = 1;
        foreach my $loop(2..$#l-1){
                $GENE{$gene}{$loop} += $l[$loop];
        }
}
close IN;

my $label_n = keys %LABEL;
foreach my $gene(sort {$a cmp $b}  keys %GENE){
        print "$gene\t";
        my $str;
        foreach my $loop(sort {$a <=> $b} keys %{$GENE{$gene}}){
                my $v = $GENE{$gene}{$loop};
                my $ave_v = sprintf("%.4f",$multi*$v/$label_n);
                print "$ave_v\t";
                $str .= "$ave_v,";
        }

        $str =~ s/,$//;
        my $p;
        if($Test){
                $p = CHISQ_TEST($str);
        }
        $p ||= "NA";

        print "$p\n";

}

sub CHISQ_TEST
{
        my $str = shift @_;
        my @s = split /\,/,$str;
        my $n = @s;
        my $sum = 0;
        foreach my $v(@s){
                $sum += $v;
        }
        my $ave = sprintf("%.4f",$sum/$n);

        my $Bv;
        foreach my $v(@s){
                $Bv .= "$ave,";
        }
        $Bv =~ s/,$//;

        my $Av = $str;

open R,">TMP.R";
print R "
library(tidyr)
library(knitr)

A <-c($Av)
B <-c($Bv)

c <- rbind(A,B)
kable(c)
chisq.test(c)
";
close R;

        my $Rinfo = `/hwfssz4/BC_PUB/Software/03.Soft_ALL/R-3.5.1/bin/Rscript TMP.R`;
        my $pvalue = $1 if $Rinfo =~ /p-value\s+\S+\s+(\S+)/;
        return $pvalue;
}



EOF





perl Loop_GeneDis.v1.pl $pseudokranz \
-split 8 -AddInfo Cell_GetExp_gene.txt.add -LDNB_xN 10 -LDNB_yN 10 -multi 100 \
> Cell_GetExp_gene.MIDCounts.density.ave

perl Loop_GeneStat.pl Cell_GetExp_gene.MIDCounts.density.ave -multi 40 > Cell_GetExp_gene.MIDCounts.density.ave.gene


#/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/zhongliyuan/miniconda3/envs/R4.1/bin/Rscript fold_change.R

