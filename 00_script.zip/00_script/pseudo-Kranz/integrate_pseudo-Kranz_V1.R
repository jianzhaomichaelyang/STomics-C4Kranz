library(getopt)
arg <- matrix(c("kranz", "k", "1", "character", "kranz data",
                "outdir", "o", "1", "character", "outdir",
                "marker", "m", "1", "character", "marker list",
                "marker colname","c","1","character","markergene colnames",
                "proname", "p", "1", "character", "proname",
                "dip", "d", "1", "character", "dip", 
                "center", "e", "1", "character", "center point", 
                "new_xy", "n", "1", "character", "new xy"
), byrow = T, ncol = 5)
opt = getopt(arg)
if (is.null(opt$outdir)){
  opt$outdir <- "output"
}
if (is.null(opt$Kranz)){
  opt$Kranz <- "/hwfssz1/ST_EARTH/P20Z10200N0035/USER/chenhanyang/A00899C3/kranzstage_EPI/kranzstage_A00899C3_all_EPI_kranztype_Zero/Cell_GetExp_gene.txt"
}
if (is.null(opt$dip)){
  opt$dip <- "/hwfssz1/ST_EARTH/P20Z10200N0035/USER/chenhanyang/A00899C3/dip/kranzstage_A00899C3_dip/Cell_GetExp_gene.txt"
}

if (is.null(opt$center)){
  opt$center <- "/hwfssz1/ST_EARTH/P20Z10200N0035/USER/chenhanyang/A00899C3/dip_rev/all/A00899C3_dip2_all_center/Cell_GetExp_gene.txt"
}

library(dplyr)
library(ggplot2)
# 读取数据文件
data <- read.table(opt$kranz, header = TRUE)
marker_list <- read.csv(opt$marker)
dip <- read.table(opt$dip, header = TRUE)
center <- read.table(opt$center, header = TRUE)
#计算每个 label 的中位数
med <- center %>% group_by(label) %>% summarize(kranz_x = median(x), kranz_y = median(y))
center2 <- left_join(center, med, by = "label")

dip_med <- dip %>% group_by(label) %>% summarize(dip_x = median(x), dip_y = median(y))
dip2 <- left_join(dip, dip_med, by = "label")

dip2$full <- paste(dip2$geneID, dip2$x, dip2$y, sep = "_")
center2$full <- paste(center2$geneID, center2$x, center2$y, sep = "_")
#center2$full <- paste(center2$geneID, new_data$x, new_data$y, sep = "_")
data$full <- paste(data$geneID, data$x, data$y, sep = "_")

dip2 <- subset(dip2, select = -c(1, 2, 3, 4, 5, 6))
center2 <- subset(center2, select = -c(1, 2, 3, 4, 5, 6))


#write.csv(dip, "dip.csv")
kranz <- left_join(data, center2, by = "full")
kranz <- left_join(kranz, dip2, by = "full")

#rotate <- function(x1, y1, x2, y2, x0, y0){
#  r0 <- sqrt((x0-x2)^2+(y0-y2)^2)
#  x <- ((x1-x2)*(x0-x2)+(y1-y2)*(y0-y2))/r0
#  y <- ((y1-y2)*(x0-x2)-(x1-x2)*(y0-y2))/r0
#  new.cor <- c(x,y)
#  return(new.cor)
#}

rotate.x <- function(x1, y1, x2, y2, x0, y0){
  r0 <- sqrt((x0-x2)^2+(y0-y2)^2)
  x <- ((x1-x2)*(x0-x2)+(y1-y2)*(y0-y2))/r0
 # y <- ((y1-y2)*(x0-x2)-(x1-x2)*(y0-y2))/r0
  #new.cor <- c(x,y)
  return(x)
}
rotate.y <- function(x1, y1, x2, y2, x0, y0){
  r0 <- sqrt((x0-x2)^2+(y0-y2)^2)
 # x <- ((x1-x2)*(x0-x2)+(y1-y2)*(y0-y2))/r0
  y <- ((y1-y2)*(x0-x2)-(x1-x2)*(y0-y2))/r0
  #new.cor <- c(x,y)
  return(y)
}



kranz.label <- unique(kranz$label)
for(i in 1:length(kranz.label)){
 dip.x <- unique(kranz[which(kranz[,"label"]==kranz.label[i]), "dip_x"])
 dip.y <- unique(kranz[which(kranz[,"label"]==kranz.label[i]), "dip_y"])
 dip.x <- dip.x[grep("\\d",dip.x)]
 dip.y <- dip.y[grep("\\d",dip.y)]
 if (length(dip.x)>0) {
kranz[which(kranz[,"label"]==kranz.label[i]), "dip_x"] <- dip.x
}
if (length(dip.y)>0) {
kranz[which(kranz[,"label"]==kranz.label[i]), "dip_y"] <- dip.y
}
}

for(i in 1:length(kranz.label)){

 kranz_x <- unique(kranz[which(kranz[,"label"]==kranz.label[i]), "kranz_x"])
 kranz_y <- unique(kranz[which(kranz[,"label"]==kranz.label[i]), "kranz_y"])
 kranz_x <- kranz_x[grep("\\d",kranz_x)]
 kranz_y <- kranz_y[grep("\\d",kranz_y)]
 if (length(kranz_x)>0) {
kranz[which(kranz[,"label"]==kranz.label[i]), "kranz_x"] <- kranz_x
}
 if (length(kranz_y)>0) {
kranz[which(kranz[,"label"]==kranz.label[i]), "kranz_y"] <- kranz_y
}
}

kranz_x <- as.numeric(na.omit(unique(kranz$kranz_x)))
dip_x <- as.numeric(na.omit(unique(kranz$dip_x)))
kranz <- kranz[which(kranz$dip_x %in% dip_x),]
kranz <- kranz[which(kranz$kranz_x %in% kranz_x),]


kranz$new.x <- rotate.x(kranz[,"x"],kranz[,"y"],kranz[,"kranz_x"],kranz[,"kranz_y"],kranz[,"dip_x"],kranz[,"dip_y"])
kranz$new.y <- rotate.y(kranz[,"x"],kranz[,"y"],kranz[,"kranz_x"],kranz[,"kranz_y"],kranz[,"dip_x"],kranz[,"dip_y"])
#for(i in 1:length(rownames(kranz))){
# new <- rotate(kranz[i,"dip_x"],kranz[i,"dip_y"],kranz[i,"kranz_x"],kranz[i,"kranz_y"],kranz[i,"x"],kranz[i,"y"])
# new <- rotate(kranz[i,"dip_x"],kranz[i,"dip_y"],kranz[i,"kranz_x"],kranz[i,"kranz_y"],kranz[i,"x"],kranz[i,"y"])
# kranz$new.x <- new.cor[1]
# kranz$new.y <- new.cor[2]
# print(i)
#}
write.csv(kranz, paste(opt$proname, "pseudo-Kranz.csv", sep = "_"))







