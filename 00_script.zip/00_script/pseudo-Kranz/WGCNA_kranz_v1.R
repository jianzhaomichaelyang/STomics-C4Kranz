######## WGCNA clustering ######## 
#::install(c("AnnotationDbi", "impute", "GO.db", "preprocessCore"))
#BiocManager::install(c("ctc", "amap"))
#install.packages("WGCNA")
library(getopt)
arg <- matrix(c("input", "i","1","character","input file1",
                "proname", "n", "1", "character","proname for saving file",
                "cycle_n", "c", "1", "numeric", "splited cycle numbers",
		"powerEstimate", "p", "1", "numeric", "soft powerestimate",
		"minModuleSize", "m", "1", "numeric", "minModuleSize for module genes",
		"trait", "t", "1", "character", "traits with cell expression relationship"
    ),byrow=T,ncol=5)
opt = getopt(arg)

if(is.null(opt$cycle_n)){
        opt$cycle_n = 8
}

if(is.null(opt$powerEstimate)){
	opt$powerEstimate = 9
}

if(is.null(opt$minModuleSize)){
	opt$minModuleSize = 20
}

options(future.globals.maxSize = 10000 * 1024^3)
#setwd("D:/C3_C4/transcriptome/kranz_genes/WGCNA/maize_5BS_late")
library(WGCNA)
#library(ctc)
library(amap)
library(doParallel);
library(dplyr)
registerDoParallel(cores= 5);

proname <- opt$proname
#读取数据
femData = read.table(opt$input, head=F, stringsAsFactors=F)
traitData = read.csv(opt$trait, header = T) 
cycle_n <- opt$cycle_n + 1
femData <- femData[,1:cycle_n]
rownames(femData) <- femData[,1]
femData <- femData[,-1]
traitData = read.csv(opt$trait, header = T)
colnames(femData) <- traitData[,1]
dim(femData)
head(femData)
names(femData)

#对原始数据的格式转换
datExpr = as.data.frame(t(femData))
datExpr[1:5, 1:5]
#检查是否存在缺失的数据
gsg = goodSamplesGenes(datExpr, verbose = 3)
gsg$allOK
datExpr0 <- datExpr
if(!gsg$allOK)
 {
  #(可选)打印被删除的基因和样本名称:
  if(sum(!gsg$goodGenes)>0)
    printFlush(paste("Removinggenes:",paste(names(datExpr0)[!gsg$goodGenes], collapse =",")));
  if(sum(!gsg$goodSamples)>0)
    printFlush(paste("Removingsamples:",paste(rownames(datExpr0)[!gsg$goodSamples], collapse =",")));
  #删除不满足要求的基因和样本:
  datExpr = datExpr0[gsg$goodSamples, gsg$goodGenes]
 }


#对样品进行聚类
sampleTree = hclust(dist(datExpr), method = "average")
pdf("01.sample_clustering.pdf")
par(cex = 0.6);
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
dev.off()

######################################################
########计算样品间相关性（基于皮尔森相关系数）########
######################################################
#clustering samples
femData2 = as.data.frame(femData)
adjacency = adjacency(femData2, type = "signed", corFnc = "cor", corOptions = "use = 'p', method = 'spearman'")
dissadjacency = 1-adjacency
sampleTree = hclust(as.dist(dissadjacency), method = "average")

pdf("02.sample_correlationship.pdf")
plot(sampleTree, xlab="", sub="", labels = NULL, hang = 0.04)
dev.off()
#heatmap of correlation matrix 
textMatrix = paste(signif(adjacency, 2))
pdf("03.sample_correlationship_heatmap.pdf")
labeledHeatmap(Matrix = adjacency, xLabels = names(femData2), yLabels = names(femData2), ySymbols = names(femData2), colorLabels = FALSE, colors = blueWhiteRed(50), textMatrix = textMatrix, setStdMargins = FALSE, cex.text = 0.6, zlim = c(0,1))
dev.off()

######################################################
#筛选soft thresholding power（软阈值，幂指数邻接函数）
######################################################
powers = c(c(1:10), seq(from = 12, to=30, by=2))#设定软阈值范围
sft = pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)
pdf("04.soft_thresholding.pdf")
par(mfrow = c(1,2))
cex1 = 0.9
# Scale-free topology fit index as a function of the soft-thresholding power
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n", main = paste("Scale independence"))
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], labels=powers,cex=cex1,col="red")
abline(h=0.5,col="red")# this line corresponds to using an R^2 cut-off of h
# Mean connectivity as a function of the soft-thresholding power
plot(sft$fitIndices[,1], sft$fitIndices[,5], xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n", main = paste("Mean connectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1,col="red")
dev.off()


# calculate the adjacencies, using the soft thresholding power 6
print(paste("sft$powerEstimate is ", sft$powerEstimate))
#if(sft$powerEstimate==NA){
softPower = opt$powerEstimate
adjacency = adjacency(datExpr, type = "signed", power = softPower)
# Turn adjacency into topological overlap（To minimize effects of noise and spurious associations, we transform the adjacency into Topological Overlap Matrix（TOM））
TOM = TOMsimilarity(adjacency)
dissTOM = 1-TOM
# Call the hierarchical clustering function
geneTree = hclust(as.dist(dissTOM), method = "average")

# export the tree order and gene_name
geneInfo_order = data.frame(geneTree$order)
write.csv(geneInfo_order, file = "05.kranz_clusters_gene_order.csv")

# Plot the resulting clustering tree (dendrogram)
pdf("05.1.Gene_dendrogram.pdf")
plot(geneTree, xlab="", sub="", main = "Gene clustering on TOM-based dissimilarity", labels = FALSE, hang = 0.04)
dev.off()

minModuleSize = opt$minModuleSize
dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM, deepSplit = 2, pamRespectsDendro = FALSE, minClusterSize = minModuleSize)
table(dynamicMods)
# Convert numeric lables into colors
dynamicColors = labels2colors(dynamicMods)
table(dynamicColors)
color1 <- data.frame(table(dynamicColors))
write.csv(color1, "05.2.dynamicColors.csv")
pdf("05.2.Gene_dendrogram_and_module_colors.pdf")
plotDendroAndColors(geneTree, dynamicColors, "Dynamic Tree Cut", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05,
main = "Gene dendrogram and module colors")
dev.off()

# Merging of modules whose expression profiles are very similar
# Calculate eigengenes
MEList = moduleEigengenes(datExpr, colors = dynamicColors)
MEs = MEList$eigengenes
# Calculate dissimilarity of module eigengenes
MEDiss = 1-cor(MEs)
# Cluster module eigengenes
METree = hclust(as.dist(MEDiss), method = "average")

# Plot the result
pdf("06.Clustering_of_module_eigengenes.pdf",  width = 16)
plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
# We choose a height cut of 0.25, corresponding to correlation of 0.75, to merge
MEDissThres = 0.25
# Plot the cut line into the dendrogram
abline(h=MEDissThres, col = "red")
dev.off()

# Call an automatic merging function
merge = mergeCloseModules(datExpr, dynamicColors, cutHeight = MEDissThres, verbose = 3)
# The merged module colors
mergedColors = merge$colors
# Eigengenes of the new merged modules:
mergedMEs = merge$newMEs
write.csv(mergedMEs, file = "07.mergedMEs.csv")
# we plot the gene dendrogram again, with the merged module colors underneath
pdf("07.merged.cluster.dendrogram.pdf",  width = 16)
plotDendroAndColors(geneTree, cbind(dynamicColors, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"), dendroLabels = FALSE, hang = 0.01,
addGuide = TRUE, guideHang = 0.05)
dev.off()

# Plot the mergedmodules
mergedMEDiss = 1-cor(mergedMEs)
# Cluster module eigengenes
mergedMETree = hclust(as.dist(mergedMEDiss), method = "average")
pdf("08.Clustering_of_mergedmodule_eigengenes.pdf")
plot(mergedMETree, main = "Clustering of module eigengenes", xlab = "", sub = "")
dev.off()

#  we will use the merged module colors in mergedColors
# Rename to moduleColors
moduleColors = mergedColors
# Construct numerical labels corresponding to the colors
colorOrder = c("grey", standardColors(50))
moduleLabels = match(moduleColors, colorOrder)-1
MEs = mergedMEs
# Save module colors and labels for use in subsequent parts
save(MEs, moduleLabels, moduleColors, geneTree, file = "09.FemaleLiver-02-networkConstruction-stepByStep.RData")

# export data
annot = read.table(file = opt$input, head=F, stringsAsFactors=F)
dim(annot)
names(annot)
annot <- annot[,1:cycle_n]
colnames(annot) <- c("gene_name", as.character(traitData[,1]))
probes = names(datExpr)
probes2annot = match(probes, annot$gene_name)
# The following is the number or probes without annotation:   
sum(is.na(probes2annot))
# Create the starting data frame holding the resluts
geneInfo = data.frame(gene_name = probes, annot[probes2annot,2:cycle_n], moduleColor = moduleColors)
geneInfo = geneInfo[order(geneInfo$moduleColor), ]
write.csv(geneInfo, file = "10.merged_clusters_expr.csv",  row.names = F)




#############################################
#############################################
######## Loading clinical trait data ########
#############################################
#############################################
#Loading trait data
allTraits = read.csv(opt$trait, header = T)
# Form a data frame analogous to expression data that will hold the clinical traits.
Samples = rownames(datExpr)
traitRows = match(Samples, allTraits$kranz.cycle)
datTraits = allTraits[traitRows, -1]
datTraits <- data.frame(datTraits)
colnames(datTraits) <- names(allTraits)[-1]
rownames(datTraits) = allTraits[traitRows, 1]
# Re-cluster samples
sampleTree2 = hclust(dist(datExpr), method = "average")
# Convert traits to a color representation: white means low, red means high, grey means missing entry
traitColors = numbers2colors(datTraits, signed = FALSE)
# Plot the sample dendrogram and the colors underneath.
pdf("11.Sample_dendrogram_and_trait_heatmap.pdf")
plotDendroAndColors(sampleTree2, traitColors, groupLabels = names(datTraits), main = "Sample dendrogram and trait heatmap")
dev.off()
##############################################################
##############################################################
######## Relating modules to external clinical traits ########
##############################################################
##############################################################
#3.a Quantifying module{trait associations
# Define numbers of genes and samples
nGenes = ncol(datExpr)
nSamples = nrow(datExpr)
# Relating modules to external clinical traits
moduleTraitCor = cor(MEs, datTraits, use = "p")
write.csv(moduleTraitCor, file = "12._ME_Traits_Cor.csv")
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, nSamples)#可以不要
# Will display correlations and their p-values
sizeGrWindow(12,9)
textMatrix = paste(signif(moduleTraitCor, 2))
dim(textMatrix) = dim(moduleTraitCor)

# Display the correlation values within a heatmap plot
pdf("12.Module_cell.relationships.pdf", width = 6)
labeledHeatmap(Matrix = moduleTraitCor, xLabels = names(datTraits), yLabels = names(MEs), ySymbols = names(MEs), colorLabels = FALSE, colors = blueWhiteRed(50), textMatrix = textMatrix, setStdMargins = FALSE, cex.text = 0.6, zlim = c(-1,1), main = paste("Module-Stage relationships"))
dev.off()
##################################################################
##################################################################
######## Gene relationship to trait and important modules ########
##################################################################
##################################################################
# names (colors) of the modules
modNames = substring(names(MEs), 3)

geneModuleMembership = as.data.frame(cor(datExpr, MEs, use = "p"));
MMPvalue = as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nSamples))
names(geneModuleMembership) = paste("MM", modNames, sep="");
names(MMPvalue) = paste("p.MM", modNames, sep="");
write.csv(geneModuleMembership, file = "13.geneModuleMembership.csv")
write.csv(geneModuleMembership, file = "13.MMPvalue.csv")


# Define variable weight containing the weight column of datTrait
dir <- getwd()
dir.create("genes.vs.trait.modules")
dir2 <- paste0(dir, "/genes.vs.trait.modules")
setwd(dir2)
trait_n <- names(allTraits)[-1]
rb.GS <- c()
cb.GS <- c()
rb.GSP <- c()
cb.GSP <- c()
for(i in 1:length(trait_n)){
  trait0 = as.data.frame(allTraits[,trait_n[i]]);
  names(trait0) = trait_n[i]
  geneTraitSignificance = as.data.frame(cor(datExpr, trait0, use = "p"));
  GSPvalue = as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance), nSamples));
  names(geneTraitSignificance) = trait_n[i];
  names(GSPvalue) = trait_n[i];
  geneTraitSignificance$gene_name <- rownames(geneTraitSignificance)
  GSPvalue$gene_name <- rownames(GSPvalue)
  geneTraitSignificance <- geneTraitSignificance[,c("gene_name", trait_n[i])]
  GSPvalue <- GSPvalue[, c("gene_name", trait_n[i])]
  if(i > 1){
   cb.GS <- left_join(cb.GS, geneTraitSignificance[,1:2], by = "gene_name")
   cb.GSP <- left_join(cb.GSP, GSPvalue[,1:2], by = "gene_name")
  }else{
   cb.GS <- geneTraitSignificance[,1:2]
   cb.GSP <- GSPvalue[,1:2]
  }
  # identifying genes with high GS and MM
  for(j in modNames){
    module = j
    column = match(module, modNames);
    moduleGenes = moduleColors==module;
    
    pdf(paste0(i, "_genes_with_high_GS_and_MM_in_module", j, ".pdf"))
    #sizeGrWindow(7, 7);
    par(mfrow = c(1,1));
    plot1 <- verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]),abs(geneTraitSignificance[moduleGenes, 1]),
                                xlab = paste("Module Membership in", module, "module"),
                                ylab = "Gene significance for vein",
                                main = paste("Module membership vs. gene significance\n"),
                                cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
    print(plot1)
    dev.off()
  } 
}
 #colnames(cb.GS) <- c(trait_n, "gene_name")
 #cb.GS <- cb.GS[, c("gene_name", trait_n)]
 #colnames(cb.GSP) <- c(trait_n, "gene_name")
 #cb.GSP <- cb.GSP[, c("gene_name", trait_n)]

 write.csv(cb.GS, "alltrait_geneTraitSignificance.cb.csv", row.names = F)
 write.csv(cb.GSP, "alltrait_GSPvalue.cb.csv", row.names = F)
setwd(dir)

##################################################################
##################################################################
##################### Box-plot for gene modules ##################
##################################################################
##################################################################
#("C:/Users/user/Desktop/2015.06.16_Petal/7. Petal clustering/Petal all genes_CV0.5")
dir <- getwd()
dir.create("Box_plot")
dir2 <- paste0(dir, "/Box_plot")
setwd(dir2)

dat <- read.csv("../10.merged_clusters_expr.csv",head=T,stringsAsFactors=F)
clu <- unique(dat[,10])
### 保存为wmf格式
#for(i in 1:length(clu))
#{
#	win.metafile(filename = paste(clu[i],".wmf",sep=""),width = 7, height = 7, pointsize = 12)
#	subdat <- dat[dat[,10]==clu[i],]
#	boxplot(subdat[,2:9],ylim=c(-2,3),ylab="z-score",outline = F,col= clu[i],font=0.5)
#	box()
#    legend("top", legend=clu[i])
#	dev.off()
#}

### 保存为pdf格式
for(i in 1:length(clu))
{
	pdf(file=paste(clu[i],".pdf",sep=""),width = 7, height = 7)
	subdat <- dat[dat[,10]==clu[i],]
	boxplot(subdat[,2:9],outline = F,col=clu[i])
	dev.off()
}

setwd(dir)





