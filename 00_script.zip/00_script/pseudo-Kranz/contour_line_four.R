library(dplyr)
library(ggplot2)
library(RColorBrewer)
library(grDevices)
library(ggpubr)

marker <- read.csv("markergenes.xx.csv", header = T)
BS4 <- read.csv("/hwfssz1/ST_EARTH/P20Z10200N0035/USER/nianting/C4_scRNA/kranz_dip/maize/A0089C3/20230518/maize_C3_4BSearly_center_dip_newxy_add.csv", header = T)
late5 <- read.csv("/hwfssz1/ST_EARTH/P20Z10200N0035/USER/nianting/C4_scRNA/kranz_dip/maize/A0089C3/20230518/maize_C3_5BSlate_center_dip_newxy_add.csv", header = T)
mature5<- read.csv("/hwfssz1/ST_EARTH/P20Z10200N0035/USER/nianting/C4_scRNA/kranz_dip/maize/A0089C3/20230518/maize_C3_5BSmature_center_dip_newxy_add.csv", header = T)


marker <- distinct(marker, gene_name, Gene_ID)

k <- list()
m <- list()
n <- list()
l <- list()

for (i in 1:nrow(marker)){
  gene <- marker[i,"Gene_ID"]
  gene_name <- marker[i,"gene_name"]
  a2 <- subset(BS4, geneID == gene, select = c("MIDCount", "new.x", "new.y"))
  a3 <- subset(late5, geneID == gene, select = c("MIDCount", "new.x", "new.y"))
  a4 <- subset(mature5, geneID == gene, select = c("MIDCount", "new.x", "new.y"))

  if (nrow(a2) >= 20){
    k[[i]] <- ggplot(a2, aes(new.x, new.y)) + stat_density2d(aes(fill = after_stat(level)), geom = "polygon", contour_var = "count") +
      scale_fill_distiller(palette = "Blues", direction = 1) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount") +
      ggtitle(paste0(gene_name,' - 4BS early')) + theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}else{
    k[[i]] <- ggplot(a2,aes(x=new.x,y=new.y, color = MIDCount)) + geom_point(size=5) + scale_color_gradient(low = "lightblue", high = "darkblue") + 
      ggtitle(paste0(gene_name,' - 4BS early')) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount") + 
      theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}
  if (nrow(a3) >= 20){
    m[[i]] <- ggplot(a3, aes(new.x, new.y)) + stat_density2d(aes(fill = after_stat(level)), geom = "polygon", contour_var = "count") +
      scale_fill_distiller(palette = "Blues", direction = 1) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount")  +
      ggtitle(paste0(gene_name,' - 5BS late')) + theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}else{
    m[[i]] <- ggplot(a3,aes(x=new.x,y=new.y, color = MIDCount)) + geom_point(size=5) + scale_color_gradient(low = "lightblue", high = "darkblue") + 
      ggtitle(paste0(gene_name,' - 5BS late')) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount") + 
      theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}
  if(nrow(a4) >= 20){
    n[[i]] <- ggplot(a4, aes(new.x, new.y)) + stat_density2d(aes(fill = after_stat(level)), geom = "polygon", contour_var = "count") +
       scale_fill_distiller(palette = "Blues", direction = 1) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount") +
      ggtitle(paste0(gene_name,' - 5BS mature')) + theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}else{
    n[[i]] <- ggplot(a4,aes(x=new.x,y=new.y, color = MIDCount)) + geom_point(size=5) + scale_color_gradient(low = "lightblue", high = "darkblue") + 
      ggtitle(paste0(gene_name,' - 5BS mature')) + labs(x = "Horizontal axis", y = "Adaxial–Abaxial axis", fill = "MIDCount")  + 
      theme(plot.title = element_text(hjust = 0.5), panel.background = element_rect(fill = "transparent")) + xlim(-80, 80) + ylim(-80, 80)
}
    l[[i]] <- ggarrange(k[[i]], m[[i]], n[[i]], 
                          ncol = 3,
                          nrow = 1
    )
 
}

pdf(paste0("markers", ".pdf"), width = 12, height= 2.86)
print(l[[i]])
dev.off()
