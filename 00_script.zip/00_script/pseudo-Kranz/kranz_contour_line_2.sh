export R_LIBS_USER=/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/wangfang/02.software/miniconda3/envs/R_4.2/lib/R/library
export R_LIBS_USER=/hwfssz1/ST_EARTH/Reference/ST_AGRIC/USER/zhongliyuan/miniconda3/envs/R4.1/lib/R/library
/hwfssz1/ST_EARTH/P20Z10200N0035/USER/xiangsunhuan/adata/Miniconda3/envs/R4.2/bin/Rscript \
/hwfssz1/ST_EARTH/P20Z10200N0035/USER/nianting/script/kranz_contour_line_V0.1_1.R \
-k /hwfssz1/ST_EARTH/P20Z10200N0035/USER/chenhanyang/A00899C3/kranzstage_EPI/kranzstage_A00899C3_all_EPI_kranztype_4BSearly/Cell_GetExp_gene.txt \
-d /hwfssz1/ST_EARTH/P20Z10200N0035/USER/chenhanyang/A00899C3/dip/kranzstage_A00899C3_dip/Cell_GetExp_gene.txt \
-p maize_C3_dip_4BSearly
