#!/usr/bin/env python
#coding: utf-8
# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import cv2
import os, sys
import time
sys.path.append("..")
import numpy as np
import gzip
import tifffile as tifi
from PIL import Image
import pandas as pd
#from line_profiler import LineProfiler
# from registration.settings import grids_x, grids_y, image_magnify, crop, crop_size
# from utils.vis2img import parse_head

usage = '''
     Usage: %s <Gene_Exp> <Output_Path> >>STDOUT
         '''

magnify_set = True
image_magnify = 0.5

## 切图的种类
crop = False
crop_size = 10000

# TRACK_DIS = grids_x#[112, 144, 208, 224, 224, 208, 144, 112, 160]

find_range = 3000


def parse_head(gem):
    """ Parse additional header info """
    if gem.endswith('.gz'):
        f = gzip.open(gem, 'rb')
    else:
        f = open(gem, 'rb')

    header = ''
    num_of_header_lines = 0
    eoh = 0
    for i, l in enumerate(f):
        l = l.decode("utf-8") # read in as binary, decode first
        if l.startswith('#'): # header lines always start with '#'
            header += l
            num_of_header_lines += 1
            eoh = f.tell() # get end-of-header position
        else:
            break

    # stlog.debug(num_of_header_lines)
    # stlog.debug(header)
    # stlog.debug(eoh)

    # find start of expression matrix
    f.seek(eoh)

    return f, num_of_header_lines, header

def save_patches(img, patch_w, patch_h, name):
    # calculate num of patches
    width, height = img.size
    num_w = int(np.ceil(width/patch_w))
    num_h = int(np.ceil(height/patch_h))
    print("{} col, {} row, total {} patches".format(num_w, num_h, num_w*num_h))

    imgs = np.zeros((patch_h, patch_w, num_w*num_h), dtype=np.uint16)
    t0 = time.time()
    for i in range(num_w):
        t1_0 = time.time()
        for j in range(num_h):
            if i < num_w-1:
                x = i*patch_w
            else:
                x = width - patch_w
            if j < num_h-1:
                y = j*patch_h
            else:
                y = height - patch_h
            
            box = (x, y, x+patch_w, y+patch_h)
            im_crop = img.crop(box)

            im_name = name+'_{}_{}_{}_{}'.format(height, width, y, x)
            im_crop.save(im_name+'.tif', compression='tiff_lzw')

        t1_1 = time.time()
        print("{} col, {:.2f} seconds".format(i, t1_1-t1_0))
    t2 = time.time()
    print("all image saved: {:.2f} seconds.".format(t2-t0))

def getMass(image):
    ## 计算图像重心
    image = image.astype(float)
    image_x = np.sum(image, 0)
    xx = np.array(range(len(image_x)))
    xx_cal = xx*image_x
    x_mass = np.sum(xx_cal)/np.sum(image_x)

    image_y = np.sum(image, 1)
    yy = np.array(range(len(image_y)))
    yy_cal = yy*image_y
    y_mass = np.sum(yy_cal)/np.sum(image_y)

    return np.array([x_mass, y_mass])

def getMassTxt(x_set, y_set):
    xx_cal = np.array(range(len(x_set))) * x_set
    x_mass = np.sum(xx_cal)/np.sum(x_set)

    yy_cal = np.array(range(len(y_set))) * y_set
    y_mass = np.sum(yy_cal)/np.sum(y_set)

    return np.array([x_mass, y_mass])

def find_firstPointTxt(x_sum, y_sum, mass_center, tracks):
    min_x = max(0, int(round(mass_center[0]) - find_range))
    max_x = int(round(mass_center[0]) + find_range)
    min_y = max(0, int(round(mass_center[1]) - find_range))
    max_y = int(round(mass_center[1]) + find_range)

    position = np.cumsum(np.array(tracks[:-1]))
    position = position.tolist()
    position.insert(0, 0)
    position = np.array(position)
    position_x = position.copy()

    x_result = []
    x_sum = x_sum[min_x : max_x]
    y_sum = y_sum[min_y : max_y]

    for fisrts_pos in range(len(x_sum) - np.max(position) - 1):
        position_x += 1
        x_result.append(sum(x_sum[position_x]))

    x_first = x_result.index(min(x_result)) + min_x + 2

    position_y = position.copy()
    y_result = []
    for fisrts_pos in range(len(y_sum) - np.max(position) - 1):
        position_y += 1
        y_result.append(sum(y_sum[position_y]))

    y_first = y_result.index(min(y_result)) + min_y + 2
    return x_first, y_first
    
def find_firstPoint(image, mass_center, tracks):
    min_x = int(round(mass_center[0]) - find_range)
    max_x = int(round(mass_center[0]) + find_range)
    min_y = int(round(mass_center[1]) - find_range)
    max_y = int(round(mass_center[1]) + find_range)
    
    find_image = image[min_y : max_y, min_x : max_x].astype(float)

    x_sum = np.sum(find_image, 0)  ## zong
    y_sum = np.sum(find_image, 1)  ## heng

    position = np.cumsum(np.array(tracks[:-1]))
    position = position.tolist()
    position.insert(0, 0)
    position = np.array(position)
    position_x = position.copy()

    x_result = []
    for fisrts_pos in range(len(x_sum) - np.max(position) - 1):
        position_x += 1
        x_result.append(sum(x_sum[position_x]))

    x_first = x_result.index(min(x_result)) + min_x + 2

    position_y = position.copy()
    y_result = []
    for fisrts_pos in range(len(y_sum) - np.max(position) - 1):
        position_y += 1
        y_result.append(sum(y_sum[position_y]))

    y_first = y_result.index(min(y_result)) + min_y + 2
    return x_first, y_first

def find_cross(path, ResultPath, grids=[240, 300, 330, 390, 390, 330, 300, 240, 420]):
    tracks = grids
    if path.endswith('.txt') or path.endswith('.tsv') or path.endswith('.gem') or path.endswith('.gz'):
        start = time.time()
        x_record, y_record = txt2image(path, ResultPath)
        end1 = time.time()
        print('txt_read :' + str(end1 - start))
        mass_center = getMassTxt(x_record[:], y_record[:])
        end2 = time.time()
        print('mass_center :' + str(end2 - end1))
        col, row = find_firstPointTxt(x_record[:], y_record[:], mass_center, tracks)
        end3 = time.time()
        print('find_firstPointTxt :' + str(end3 - end2))
        width = len(y_record); height = len(x_record)
    else:
        image = tifi.imread(path)
        img2 = Image.fromarray(image)
        img_re = img2.resize((int(img2.size[0]*image_magnify), int(img2.size[1]*image_magnify)), resample=Image.NEAREST)
        # filename = os.path.splitext(os.path.basename(path))[0]
        filename = os.path.basename(path).split('.')[0]
        if not os.path.exists(ResultPath):
            os.makedirs(ResultPath)
        img2.save(os.path.join(ResultPath, filename+'.tif'), compression="tiff_lzw")
        img_re.save(os.path.join(ResultPath, filename+'_'+str(image_magnify)+'.tif'), compression="tiff_lzw")
        mass_center = getMass(image)
        end2 = time.time()
        col, row = find_firstPoint(image, mass_center, tracks)
        end3 = time.time()
        width, height = image.shape
    
    orig_row = row
    orig_col = col
    row_id = [orig_row]
    col_id = [orig_col]
    flag = 0
    rg_row = orig_row
    lf_row = orig_row
    up_col = orig_col
    dw_col = orig_col

    row_id_record = [0] ### 行
    col_id_record = [0] ### 列
    while True:
        # row
        index = flag % 9
        rg_row += tracks[index]
        lf_row -= tracks[8 - index]
        up_col += tracks[index]
        dw_col -= tracks[8 - index]
        if rg_row > width and lf_row < 0 and up_col > height and dw_col < 0:
            break
        if rg_row <= width:
            row_id_record.append((index + 1) % 9)
            row_id.append(round(rg_row, 3))
        if lf_row >= 0:
            row_id_record.append(8 - index)
            row_id.append(round(lf_row, 3))
        if up_col <= height:
            col_id_record.append((index + 1) % 9)
            col_id.append(round(up_col, 3))
        if dw_col >= 0:
            col_id_record.append(8 - index)
            col_id.append(round(dw_col, 3))
        flag += 1

    end4 = time.time()
    print('find_cross :' + str(end4 - end3))

    # filepath, temp_filename = os.path.split(path)
    # filename, _ = os.path.splitext(temp_filename)
    filename = os.path.basename(path).split('.')[0]

    if not os.path.exists(ResultPath):
        os.makedirs(ResultPath)
    np.savetxt(os.path.join(ResultPath, 'visionMass.txt'), mass_center)

    id_record = []
    coord_record = []
    for row_num, row in enumerate(row_id):
        for col_num, col in enumerate(col_id):
            coord_record.append(np.array([col, row]))
            id_record.append(np.array([col_id_record[col_num], row_id_record[row_num]]))
    np.savetxt(os.path.join(ResultPath, filename + '_tc.txt'), np.array(coord_record))
    np.savetxt(os.path.join(ResultPath, filename + '.txt'), id_record)
    end5 = time.time()
    print('output_cross :' + str(end5 - end4))

def txt2image(txt, ResultPath):
    """ Convert expression matrix data to image. """
    out_dir = ResultPath
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    # Read from txt
    t0 = time.time()
    f, num_of_header_lines, header = parse_head(txt)
    print("Number of header lines: {}".format(num_of_header_lines))
    print("Header info: \n{}".format(header))
    df = pd.read_csv(f, sep='\t', header=0)
    t1 = time.time()
    print("read txt: {:.2f}".format(t1-t0))
    # print(df)

    # Get image dimension and count each pixel's gene numbers
    print("min x: {} min y: {}".format(df['x'].min(), df['y'].min()))
    xmi = 0 # df['x'].min()
    ymi = 0 # df['y'].min()
    df['x'] = df['x']-xmi
    df['y'] = df['y']-ymi

    xma = df['x'].max()
    yma = df['y'].max()
    max_x = xma+1
    max_y = yma+1

    with open(os.path.join(out_dir, 'min_max.txt'), 'w') as fw:
        fw.write(str(xmi) + '\n')
        fw.write(str(ymi) + '\n')
        fw.write(str(xma) + '\n')
        fw.write(str(yma) + '\n')
    print("image dimension: {} x {} (width x height)".format(max_x, max_y))
    t2 = time.time()
    print("get min max: {:.2f}".format(t2-t1))

    try:
        new_df = df.groupby(['x', 'y']).agg(UMI_sum=('UMICount', 'sum')).reset_index()
    except:
        new_df = df.groupby(['x', 'y']).agg(UMI_sum=('MIDCount', 'sum')).reset_index()
    t3 = time.time()
    print("add up: {:.2f}".format(t3-t2))

    # Set image pixel to gene counts
    image = np.zeros(shape=(max_y, max_x), dtype=np.uint8)   # from uint16 to uint8
    image[new_df['y'], new_df['x']] = new_df['UMI_sum']
    t4 = time.time()
    print("add up 2: {:.2f}".format(t4-t3))
    # print(new_df)

    # Save image (thumbnail image & crop image) to file
    # filename = os.path.splitext(os.path.basename(txt))[0]
    filename = os.path.basename(txt).split('.')[0]
    out_dir = ResultPath
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    img = Image.fromarray(image)
    #img.save(os.path.join(out_dir, filename+'.tif'), compression="tiff_lzw")
    tifi.imwrite(os.path.join(out_dir, filename+'.tif'), image)

    #if isinstance(image_magnify, float) and image_magnify > 0:
    #    img_re = img.resize((int(img.size[0]*image_magnify), int(img.size[1]*image_magnify)), resample=Image.NEAREST)
    #    img_re.save(os.path.join(out_dir, filename+'_'+str(image_magnify)+'.tif'), compression="tiff_lzw")
    
    if crop:
        crop_dir = os.path.join(out_dir, 'crop')
        if not os.path.exists(crop_dir):
            os.mkdir(crop_dir)
        name = os.path.join(crop_dir, filename)
        save_patches(img, crop_size, crop_size, name)

    t5 = time.time()
    return np.sum(image, 0).astype('float64'), np.sum(image, 1).astype('float64')

def main():
    ######################### Phrase parameters #########################
    import argparse
    ArgParser = argparse.ArgumentParser(usage=usage)

    (para, args) = ArgParser.parse_known_args()

    if len(args) != 2:
        ArgParser.print_help()
        sys.stderr.write("\n[ERROR]: The parameters number is not correct!")
        sys.exit(1)
    else:
        gem = args[0]
        out_path = args[1]

    find_cross(gem, out_path)

if __name__ == '__main__':
    # path = r'E:\file\aligns\DP8400013846TR_F5_01_DP_10X_20210125.txt'
    # find_cross(path, r'E:\file\aligns\trackCross')
    main()
