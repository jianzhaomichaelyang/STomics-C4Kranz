
###convert png to tif file
import glob #加载glob库
from PIL import Image #调用PIL库
Image.MAX_IMAGE_PIXELS = None #解除图像大小限制
for i in glob.glob(r'*.png'): #将文件夹内所有图片执行格式转换，格式可变换
    im = Image.open(i,"r")
    print(i.split(".")[0]) #读取文件名
    im.save("mask.tif",quality=95) #存储文件名
   
# -*- coding: utf-8 -*-
##convert tif mask to matrix.txt
import pandas as pd
import numpy as np
import cv2
import os, sys
import tifffile as tifi
import matplotlib.pyplot as plt

def main():
    """
    %prog <Gene expression matrix> <Mask> <output Path>

    return gene expression matrix under each cell
    """

    if len(sys.argv) != 4:
        print("Inputs are not correct")
        print(main.__doc__)
        sys.exit(1)

    geneFile = sys.argv[1]
    maskFile = sys.argv[2]
    outpath = sys.argv[3]
    os.makedirs(outpath, exist_ok=True)

    print("Loading mask file...")
    mask = tifi.imread(maskFile)
    mask[mask!=0] = 1
    num_l, maskImg = cv2.connectedComponents(mask)
    print(num_l, len(np.unique(maskImg[:])))


    print("Reading data..")
#    typeColumn = {"geneID": 'str', "x": np.uint32, "y": np.uint32, "values": np.uint32, "UMICount": np.uint32}
    typeColumn = {"geneID": 'str', "x": np.uint32, "y": np.uint32, "MIDCount": np.uint32, "ExonCount": np.uint32}
    genedf = pd.read_csv(geneFile, sep='\t', dtype=typeColumn)

    tissuedf = pd.DataFrame()
    dst = np.nonzero(maskImg)

    print("Dumping results...")

    tissuedf['x'] = dst[1] + genedf['x'].min()
    tissuedf['y'] = dst[0] + genedf['y'].min()
    tissuedf['label'] = maskImg[dst]

    res = pd.merge(genedf, tissuedf, on=['x', 'y'], how='inner')

    res.to_csv(os.path.join(outpath, "Cell_GetExp_gene.txt"), sep='\t', index=False)


if __name__ == '__main__':
    main()
