setwd("D:/华为云盘/C3_C4/maize_B73/A00899C3/split3_all_cells.2")
library(Seurat)
library(ggplot2)
### loading data
rds <- readRDS("A00899C3_split3.rds")
rds <- ScaleData(rds, features = rownames(rds))

### loading modules
modules <- read.csv("D:/华为云盘/C3_C4/maize_B73/scRNA_seq/hotspot_unsheath_cells/min40/modules.csv")
mods <- unique(modules$Module)

### calculate the scaled average expression  
scale.data <- rds@assays$Spatial@scale.data

for(i in 1:length(mods)){
  gene0 <- modules[which(modules$Module == mods[i]), "gene"]
  genes <- gene0[which(gene0 %in% rownames(scale.data))]
  dat <- scale.data[genes, ]
  mod.ave <- colMeans(dat)
  proname1 <- paste("module", mods[i], "ave.exp", sep = "_")
  rds@meta.data[, proname1] <- mod.ave
  
}

vein.mod <- c(11,13,12,5,3,4)
vein.mod.n <- paste("module", vein.mod, "ave.exp", sep = "_")

dp1 <- SpatialFeaturePlot(rds, features = vein.mod.n, stroke = 0,alpha = c(1, 1), pt.size.factor = 25)

vein.exp <- rds@meta.data[, vein.mod.n]
#write.csv(vein.exp, "module_expression_in_spatial.csv")


for (i in 1:nrow(vein.exp)) {
  max_gene_index <- which.max(vein.exp[i, ])
  max_gene <- colnames(vein.exp)[max_gene_index]
#  vein.exp[i, "color"] <- my_colors[max_gene_index]
  vein.exp[i, "max.module"] <- vein.mod.n[max_gene_index]
  vein.exp[i, "vein.exp"] <- vein.exp[i, max_gene]
  
}

#rds$color <- vein.exp$color
rds$max.module <- vein.exp$max.module
rds$vein.exp <- vein.exp$vein.exp

size_factor <- ((vein.exp$vein.exp - min(vein.exp$vein.exp)) / (max(vein.exp$vein.exp)-min(vein.exp$vein.exp)))*80
rds$size_factor <- size_factor
SpatialDimPlot(rds, group.by = "max.module", stroke = 0,alpha = c(1, 1), pt.size.factor = rds$size_factor)

