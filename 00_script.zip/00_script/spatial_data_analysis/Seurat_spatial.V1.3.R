library(getopt)
#library(Matrix)

arg <- matrix(c("input", "i","1","character","input file1",
                "outdir","o","1","character","outdir",
                "sample","s","1","character","sample,default=Maize",
                "tissue","t","1","character","tissue,default=Embro",
                "dims","d","1","integer","dims option for FindNeighbors,default=15",
                "resolution","r","1","numeric","resolution option for FindClusters,[0.4-1.2],default=1",
                "help","h","0","logical", "Usage: Rscript runiDrop.R -i <input> -o <outdir> [-s SAMPLE -t TISSUE]",
		"min.cells","c","1","integer","minimum cell numbers for each gene, i.e. min.cells=3, default=3", 
		"minCG","m","1","integer","minimum gene number for each cell, i.e. nFeature_RNA, default=200",
                "rds","f","0","logical", "Save the RDS file",
                "list","l","1","character", "interested gene",
                "pt.size","p","1","numeric","pt.size for spatialdimplot",
		"featurePlot","k","1","character","T or F",
                "features","g","1","character","plot genes expression",
		"speciesmarkerlist","z","1","character","choose a species for marker list mapping"
                ),byrow=T,ncol=5)
opt = getopt(arg)
#if(!is.null(opt$help) || is.null(opt$input)){
#        cat(paste(getopt(arg, usage = T), "\n"))
# q()
#}
if (is.null(opt$sample)){
        opt$sample <- "sample"
}
if (is.null(opt$tissue)){
        opt$tissue <- "tissue"
}
if (is.null(opt$outdir)){
        opt$outdir <- "output"
}
if (is.null(opt$minCG)){
        opt$minCG <- 10
}
if (is.null(opt$min.cells)){
        opt$min.cells <- 0
}
if (is.null(opt$dims)){
        opt$dims <- 30
}
if (is.null(opt$resolution)){
        opt$resolution <- 1
}
if (is.null(opt$minCG)){
	opt$minCG <- 0
}
if (is.null(opt$pt.size)){
 opt$pt.size <- 2
}
if (is.null(opt$featurePlot)){
 opt$featurePlot <- F
}
if (is.null(opt$speciesmarkerlist)){
  opt$speciesmarkerlist <- "gene_ID_V5"
}

options(future.globals.maxSize = 4000 * 1024^2)

#seurat using spatial data
library(harmony)
library(dplyr)
library(tidyr)
library(Seurat)
library(stringr)
library(patchwork)
library(ggplot2)
library(cowplot)

#dir.create(opt$outdir);

#setwd(opt$outdir)


print("loading data")
st_rds <- readRDS(opt$input)
st_rds <- subset(st_rds, subset = nFeature_Spatial > opt$minCG)
#name1 <- strsplit(opt$input,"/",fixed=T)[[1]][length(strsplit(opt$input,"/",fixed=T)[[1]])]
#name1 <- gsub("_spatialObj.rds", "", name1)

#st_rds$batch <- name1

pdf("01.genes_MIDcounts.plot.pdf", width = 16, height = 8)
p1 <- VlnPlot(st_rds, features = "nFeature_Spatial")
p2 <- VlnPlot(st_rds, features = "nCount_Spatial")
p3 <- SpatialFeaturePlot(st_rds, features = "nFeature_Spatial", stroke = 0, max.cutoff = 5000, pt.size.factor = 20) + theme(legend.position = "right")
p4 <- SpatialFeaturePlot(st_rds, features = "nCount_Spatial", stroke = 0, max.cutoff = 10000, pt.size.factor = 20) + theme(legend.position = "right")
wrap_plots(p1, p3)
wrap_plots(p2, p4)
dev.off()

##merge and integration

print("Normalizationing")
st_rds <- SCTransform(st_rds, assay = "Spatial", verbose = FALSE)

#print("ScaleData")
#st_rds <- ScaleData(st_rds,features = rownames(st_rds), verbose = TRUE)


##Dimensionality reduction, clustering, and visualization

print("RunPCA")
st_rds <- RunPCA(st_rds, assay = "SCT", verbose = T)

pdf("03.ElbowPlot.pdf", width = 10)
ElbowPlot(object = st_rds)
dev.off()

###
print("reduction")
set.seed(100)
st_rds <- FindNeighbors(st_rds, reduction = "pca", dims = 1:opt$dims)
st_rds <- FindClusters(st_rds, resolution = opt$resolution, verbose = FALSE)
st_rds <- RunUMAP(st_rds,reduction = "pca", dims = 1:opt$dims)

print('UMAP')
plot1 <- DimPlot(object = st_rds, reduction = "umap", label = T, pt.size=1)
plot6 <- SpatialDimPlot(object = st_rds, stroke = 0,label = T, pt.size.factor = 20)
pdf("04.umap.pdf", width = 16)
print(plot1+plot6)
dev.off()

#no label
plot1.1 <- DimPlot(object = st_rds, reduction = "umap", label = F, pt.size=1)
plot6.1 <- SpatialDimPlot(object = st_rds, stroke = 0,label = F, pt.size.factor = 20)
pdf("04.umap_nolabel.pdf", width = 16)
print(plot1+plot6.1)
dev.off()

##save rds
st_rds
saveRDS(st_rds,file="tissue_merge.RDS")

#split Dimplot
st_rds <- readRDS('tissue_merge.RDS')
cluster_number <- length(as.character(unique(st_rds@meta.data[['seurat_clusters']])))

print('spatial cluster')
split_plot <- list()
for (i in 1:cluster_number){
  split_plot[[i]] <- SpatialDimPlot(st_rds, cells.highlight = CellsByIdentities(object = st_rds, idents = c(i-1)), facet.highlight = T, pt.size.factor = 20,stroke = 0)
}
pdf('04.spatial_cluster.PDF')
print(split_plot)
dev.off()

print('spatial features & counts')
pdf("04.nfeature,ncounts.plot.pdf", width = 16)
FeaturePlot(object = st_rds, reduction = "umap",features = c("nCount_Spatial", "nFeature_Spatial"),  pt.size=1)
SpatialFeaturePlot(object = st_rds, combine = F, features = c("nCount_Spatial", "nFeature_Spatial"),stroke = 0, pt.size.factor = 20)
dev.off()


st_rds
saveRDS(st_rds,file="tissue_merge.RDS")

print('marker list')
###all marker genes
adata.markers <- FindAllMarkers(st_rds, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
allmakers <- adata.markers %>% group_by(cluster)
write.csv(allmakers,file = "05.markergenes_list.int.csv")

print('marker heatmap')
###top10 marker genes heatmap
top10 <- adata.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
h <- length(unique(top10$gene))/5
pdf('05.top10_markergenes.heatmap.integreted.pdf',width = 20 , height = h )
DoHeatmap(st_rds, features = unique(top10$gene))
dev.off()


print('marker spatial plot')
pdf ("05.top10.markergene.spatial.plot.pdf", width =20, height = 30)
top10 <- adata.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
SpatialFeaturePlot(st_rds, features = unique(top10$gene), combine =F, stroke = 0, alpha = c(1, 1), pt.size.factor = 25)
dev.off()

print('loading input marker list')
features <- read.csv(opt$features,header = T)
genes <- unlist(features[,opt$speciesmarkerlist])
genes <- unique(genes)
genes <- genes[which(genes%in%rownames(st_rds))]
genes <- unique(genes)

print('input heatmap')
h <- length(genes)/5
pdf("06.input.feature.heatmap.pdf",width = 20, height = h)
heatmap <- DoHeatmap(st_rds, features = genes, slot = "scale.data",)
print(heatmap)
dev.off()

print('input spatial plot')
pdf("06.input.featurePlot.pdf")
input.feature.plot <- SpatialFeaturePlot(st_rds, features = genes, combine = F,stroke = 0,alpha = c(1, 1), pt.size.factor = 25)
print(input.feature.plot)
dev.off()



# print('Spatial variable marker - markvariogram')
# #spatially variable features
# st_rds <- FindSpatiallyVariableFeatures(st_rds, assay = "SCT", features = VariableFeatures(st_rds)[1:1000],selection.method = "markvariogram")
# top.features_markvariogram <- head(SpatiallyVariableFeatures(st_rds, selection.method = "markvariogram"), 10)
# print('markvariogram list')
# write.csv(top.features_markvariogram,file = "07.top10.features_markvariogram.csv")
# print('markvariogram plot')
# pdf('07.SpatiallyVariableFeatures_markvariogram.pdf',width = 20)
# markvariogram_plot <- SpatialFeaturePlot(st_rds, features = top.features_markvariogram, alpha = c(1, 1), pt.size.factor = 25)
# print(markvariogram_plot)
# dev.off()
# 
# print('Spatial variable marker - moransI')
# st_rds <- FindSpatiallyVariableFeatures(st_rds, assay = "SCT",slot = 'scale.data', features = VariableFeatures(st_rds)[1:1000],selection.method = "moransi", x.cuts = 100, y.cuts = 100)
# top.features_moransi <- head(SpatiallyVariableFeatures(st_rds, selection.method = "moransi"), 10)
# print('moransi list')
# write.csv(top.features_moransi,file = "07.top10.features_moransi.csv")
# print('moransi plot')
# pdf('07.SpatiallyVariableFeatures_markvariogram.pdf',width = 20)
# moransi_plot <- SpatialFeaturePlot(st_rds, features = top.features_moransi, alpha = c(1, 1), pt.size.factor = 25, max.cutoff = 'q95')
# print(moransi_plot)
# dev.off()








