import cv2
import numpy as np
import argparse
from typing import Union, List
import os
import os.path as osp
##################################################
# Dict Prepare
##################################################
def reverse_dict(d):
    return {v: k for k, v in d.items()}
def reverse_dict_list(d):
    return {v: k for k, l in d.items() for v in l}

def make_dir(dir_path):
    if not osp.exists(dir_path):
        print(f'{dir_path} is not exists, creating...')
        os.makedirs(dir_path)

RGB2CLASS = {(0, 0, 0): 'background',
             (241, 13, 163): 'preZero1',
             (254, 183, 230): 'preZero2',
             (164, 86, 137): 'preZero3',
             (120, 234, 255): 'Zero',
             (253, 48, 86): '4BSearly',
             (174, 120, 255): '5BSlate',
             (166, 255, 168): '5BSmature',
             (255, 96, 0): 'Rank1vein',
             (1, 84, 255): 'TBD'}
CLASS2RGB = reverse_dict(RGB2CLASS)

GROUP2TYPES = {
    #'TBD1': ['TBD'],
    'kranztype':['Zero', '4BSearly', '5BSlate', '5BSmature', 'Rank1vein', 'TBD'],
    'preZero' : ['preZero1', 'preZero2', 'preZero3']
}
TYPES2GROUP = reverse_dict_list(GROUP2TYPES)
#ALL = ['preZero', 'AllnoTBD', 'TBD']
ALL = ['preZero', 'kranztype']



#########################################################################################
# Arg Parse
#########################################################################################
def parse_args():
    parser = argparse.ArgumentParser(description='Extract the specific part of the image')
    parser.add_argument('input', type=str, default='input.png', help='rgb image')
    parser.add_argument('-o', '--out_dir', type=str, default='auto', help='output directory, default is auto, auto will take input\'s prefix as output directory, e.g. SS200000676TLE6_all.png -> SS200000676TLE6_all')
    parser.add_argument('-n', '--no', action='store_true', help='not generate all parts defined in GROUP2TYPES, default is false')
    parser.add_argument('-c', '--cell_type', nargs='+', type=str, default=None, help='custom cell type to extract, default is None')
    parser.add_argument('-g', '--group', nargs='+', type=str, default=None, help='custom cell group to extract, default is None')
    parser.add_argument('-p', '--print', action='store_true', help='use tree print result dir')
    args = parser.parse_args()
    return args

def get_rgb(x, y, rgb):
    x = int(x)
    y = int(y)
    r = rgb[x, y, 0]
    g = rgb[x, y, 1]
    b = rgb[x, y, 2]
    return r, g, b

def generate_mask(cls: Union[str, List[str]]):
    if isinstance(cls, str):
        cls = [cls]
    for c in cls:
        assert c in CLASS2RGB.keys(), f'{c} is not in cell types, modify the CLASS2RGB dict if needed'
    print(f'extracting {", ".join(cls)}')
    plot_rgb = plot.copy()
    plot_gray = plot.copy()
    for cnt in contours:
        (x, y), _ = cv2.minEnclosingCircle(cnt)
        cnt_rgb = get_rgb(y, x, rgb_img)
        try:
            if RGB2CLASS[cnt_rgb] in cls:
                plot_rgb = cv2.fillConvexPoly(plot_rgb, cnt, [int(x) for x in cnt_rgb])
                plot_gray = cv2.fillConvexPoly(plot_gray, cnt, (255, 255, 255))
            else:
                plot_rgb = cv2.fillConvexPoly(plot_rgb, cnt, (0, 0, 0))
                plot_gray = cv2.fillConvexPoly(plot_gray, cnt, (0, 0, 0))
        except KeyError:
            plot_rgb = cv2.fillConvexPoly(plot_rgb, cnt, (0, 0, 0))
            plot_gray = cv2.fillConvexPoly(plot_gray, cnt, (0, 0, 0))
    plot_rgb = cv2.cvtColor(plot_rgb, cv2.COLOR_BGR2RGB)
    plot_gray = cv2.cvtColor(plot_gray, cv2.COLOR_RGB2GRAY)
    return plot_rgb, plot_gray

if __name__ == '__main__':
    args = parse_args()

    input = args.input
    prefix = osp.basename(input).split('.')[0]

    out_dir = args.out_dir
    if out_dir == 'auto':
        out_dir = osp.join(osp.dirname(input), prefix)

    rgb_dir = osp.join(out_dir, 'rgb')
    gray_dir = osp.join(out_dir, 'gray')

    make_dir(out_dir)
    make_dir(rgb_dir)
    make_dir(gray_dir)


    rgb_img = cv2.imread(input)
    rgb_img = cv2.cvtColor(rgb_img, cv2.COLOR_BGR2RGB)
    gray = np.where(rgb_img[:, :, 0] != 0, 255, 0).astype(np.uint8)
    plot = np.zeros(rgb_img.shape, np.uint8)

    contours, cnts = cv2.findContours(gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if args.no:
        pass
    else:
        cv2.imwrite(osp.join(rgb_dir, f'{prefix}_all_all.png'), rgb_img)
        cv2.imwrite(osp.join(gray_dir, f'{prefix}_all_all.png'), gray)
        for group, cell_types in GROUP2TYPES.items():
            if group in ALL:
                plot_rgb, plot_gray = generate_mask(GROUP2TYPES[group])
                cv2.imwrite(osp.join(rgb_dir, f'{prefix}_{group}_all-{group}.png'), plot_rgb)
                cv2.imwrite(osp.join(gray_dir, f'{prefix}_{group}_all-{group}.png'), plot_gray)

            for cell_type in cell_types:
                plot_rgb, plot_gray = generate_mask(cell_type)
                cv2.imwrite(osp.join(rgb_dir, f'{prefix}_{group}_{cell_type}.png'), plot_rgb)
                cv2.imwrite(osp.join(gray_dir, f'{prefix}_{group}_{cell_type}.png'), plot_gray)

    if args.group is not None and args.cell_type is not None:
        raise ValueError('either group or cell_type should be specified, but not both, for group can be inferred from cell_type')

    if args.group is not None:
        for g in args.group:
            plot_rgb, plot_gray = generate_mask(GROUP2TYPES[g])
            cv2.imwrite(osp.join(rgb_dir, f'{prefix}_{g}_all-{g}.png'), plot_rgb)
            cv2.imwrite(osp.join(gray_dir, f'{prefix}_{g}_all-{g}.png'), plot_gray)
        
    if args.cell_type is not None:
        cell_type = args.cell_type
        group = [TYPES2GROUP[c] for c in cell_type]
        group = '&'.join(group)
        cell_type = '&'.join(cell_type)
        plot_rgb, plot_gray = generate_mask(args.cell_type)
        cv2.imwrite(osp.join(rgb_dir, f'{prefix}_{group}_{cell_type}.png'), plot_rgb)
        cv2.imwrite(osp.join(gray_dir, f'{prefix}_{group}_{cell_type}.png'), plot_gray)

if args.print:
    os.system(f'cd {out_dir} && tree')