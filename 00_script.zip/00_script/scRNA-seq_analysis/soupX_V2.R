##对自动筛选的细胞进而二次质控，筛选低质量的细胞，然后再计算背景值。

library(getopt)
arg <- matrix(c("rawMatrix","r","1","character","raw matrix",
		"filterMatrix","f","1","character","filter matrix",
		"minCG","m","1","integer","minimum gene number for each cell, i.e. nFeature_RNA, default=0",
                "tfidfMin","t","1","integer","default = 1, Minimum value of tfidf to accept for a marker gene",
		"setContaminationFraction","c","1","character","do setContaminationFraction or not, T or F",
		"rho","o","1","integer","set the rho of setContaminationFraction"
		),byrow=T,ncol=5)
opt = getopt(arg)
if (is.null(opt$minCG)){
    opt$minCG <- 0
}
if (is.null(opt$tfidfMin)){
    opt$tfidfMin <- 1
}
if (is.null(opt$rawMatrix)){
    opt$rawMatrix <- "02.cDNAAnno/RawMatrix"
}
if (is.null(opt$filterMatrix)){
    opt$filterMatrix <- "04.Matrix/FilterMatrix"
}
if (is.null(opt$setContaminationFraction)){
    opt$setContaminationFraction <- F
}

if (is.null(opt$rho)){
    opt$rho <- 0.1
}


library(DropletUtils)
library(SoupX)
library(Seurat)

options(future.globals.maxSize = 100000 * 1024^3)
setwd("./")

toc <- Read10X(opt$filterMatrix,gene.column=1)
tod <- Read10X(opt$rawMatrix,gene.column=1)

#tod <- tod[rownames(toc),]

all <- toc
all <- CreateSeuratObject(all)
all <- subset(all, subset = nFeature_RNA > opt$minCG ) 
all <- NormalizeData(all, normalization.method = "LogNormalize", scale.factor = 10000)
all <- FindVariableFeatures(all, selection.method = "vst", nfeatures = 3000)
all <- ScaleData(all)

all <- RunPCA(all, features = VariableFeatures(all), npcs = 40, verbose = F)
all <- FindNeighbors(all, dims = 1:30)
all <- FindClusters(all, resolution = 0.5)
all <- RunUMAP(all, dims = 1:30)

matx <- all@meta.data
toc <- all@assays[["RNA"]]@counts

raw <- CreateSeuratObject(tod)
tod <- raw@assays[["RNA"]]@counts
tod <- tod[rownames(all),]

sc = SoupChannel(tod, toc)
sc = setClusters(sc, setNames(matx$seurat_clusters, rownames(matx)))
sc = autoEstCont(sc, tfidfMin = opt$tfidfMin, forceAccept = T)
if(opt$setContaminationFraction){
sc = setContaminationFraction(sc, opt$rho)
}
#samp <- c("Bone_marrow","PBMC","Pineal_gland")
#if (length(grep("Bone_marrow|PBMC|Pineal_gland","$name"))==0) {
#    if (unique(sc$metaData$rho) < 0.2) {
 #       sc = setContaminationFraction(sc, 0.2)
#    }
#}

out = adjustCounts(sc)
#saveRDS(sc,"sc.rds")

#write.csv(out, "matrix.csv")
DropletUtils:::write10xCounts("./soupX_matrix", out,version="3")
rm(sc)

new.rds <- CreateSeuratObject(out)
new.rds <- subset(new.rds, subset = nFeature_RNA > 500 )
new.rds <- NormalizeData(new.rds, normalization.method = "LogNormalize", scale.factor = 10000)
new.rds <- FindVariableFeatures(new.rds, selection.method = "vst", nfeatures = 3000)
all.genes <- rownames(new.rds)
new.rds <- ScaleData(new.rds, features = all.genes)

new.rds <- RunPCA(new.rds, features = VariableFeatures(new.rds), npcs = 40, verbose = F)
new.rds <- FindNeighbors(new.rds, dims = 1:30)
new.rds <- FindClusters(new.rds, resolution = 0.5)
new.rds <- RunUMAP(new.rds, dims = 1:30)

pdf("01.soupx.matrix.genes_UMIcounts.pdf")
VlnPlot(new.rds, features = c("nFeature_RNA", "nCount_RNA"))
dev.off()

##dimplot and feature plot
print("dimplot and feature plot")
pdf("02_soupx.matrix.umap.pdf", width = 24, height=8)
plot1 <- DimPlot(object = new.rds, reduction = "umap", label = T,pt.size=0.5,group.by = "ident")
plot1.1 <- FeaturePlot(new.rds, features = c("nFeature_RNA","nCount_RNA"), reduction = "umap", label = T, combine = F, order = T)
print(plot1+plot1.1)
dev.off()




