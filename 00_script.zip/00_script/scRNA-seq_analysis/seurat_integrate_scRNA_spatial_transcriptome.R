library(getopt)
arg <- matrix(c("scRNA_data", "c","1","character","input scRNA data rds",
                "spatial_data","t","1","character","input spatial data rds",
                "outdir","o","1","character","outdir direction",
		"proname","n","1","character","proname for file saved",           
		"pt.size","s","1","numeric","pt.size for plot",
		"featurePlot","p","1","character","T or F",
                "marker.colname","k","1","character","markergene colnames",
                "features","g","1","character","plot genes expression"
                ),byrow=T,ncol=5)
opt = getopt(arg)
if (is.null(opt$scRNA_data)){
        opt$sample <- "Maize"
}
if (is.null(opt$spatial_data)){
        opt$spatial_dat <- "spatialObj.rds"
}
if (is.null(opt$outdir)){
        opt$outdir <- "output"
}
if (is.null(opt$featurePlot)){
        opt$dims <- F
}
if (is.null(opt$proname)){
        opt$proname <- "seurat_sc_ST"
}
if (is.null(opt$pt.size)){
        opt$pt.size <- 25
}


options(future.globals.maxSize = 10000 * 1024^3)
library(Seurat)
#library(SeuratData)
library(ggplot2)
library(patchwork)
library(dplyr)


#setwd(opt$outdir)

###loading scRNA rds as reference data
reference_dat <- readRDS(opt$scRNA_data)

##preprocess normalize data with SCTransform to compare with spatial data later
reference_dat <- SCTransform(reference_dat, ncells = 3000, verbose = FALSE) %>%
    RunPCA(verbose = FALSE) %>%
    RunUMAP(dims = 1:30)


## tmp data with seurat_clusters, no exactly identified annotation
##display the seurat umap data by harmonyu
name1 <- paste("01", opt$proname, "umap_Rawclusters.pdf", sep = "_")
pdf(name1, width = 16, height=8)
plot1 <- DimPlot(reference_dat, reduction = "umap", group.by = "seurat_clusters", label = TRUE)
plot1.1 <- FeaturePlot(reference_dat, features = "nFeature_RNA", reduction = "umap", label = T, combine = F, order = T)
plot1 + plot1.1
dev.off()


##loading the spatial rds data

spatial_dat <- readRDS(opt$spatial_data)
spatial_dat <- subset(spatial_dat, subset = nFeature_Spatial > 10)
spatial_dat <- SCTransform(spatial_dat, assay = "Spatial", verbose = FALSE) %>%
    RunPCA(verbose = FALSE)

##find anchors and transfer labels
anchors <- FindTransferAnchors(reference = reference_dat, query = spatial_dat, normalization.method = "SCT")
predictions.assay <- TransferData(anchorset = anchors, refdata = reference_dat$seurat_clusters, prediction.assay = TRUE,
    weight.reduction = spatial_dat[["pca"]], dims = 1:30)
spatial_dat[["predictions"]] <- predictions.assay

##get prediction scores for each spot for each class
DefaultAssay(spatial_dat) <- "predictions"
sc_clusters <- rownames(spatial_dat)
name2 <- paste("02.1", opt$proname, "prediction_seurat.clusters.pdf", sep = "_")
pdf(name2, width = 16, height=24)
sfp1 <- SpatialFeaturePlot(spatial_dat, features = sc_clusters, pt.size.factor = opt$pt.size, alpha = c(0.3, 1), stroke = 0, ncol = 4, crop = TRUE)
print(sfp1)
dev.off()

name3 <- paste("02.2", opt$proname, "prediction_seurat.clusters.pdf", sep = "_")
pdf(name3, width = 16, height=24)
sfp2 <- SpatialFeaturePlot(spatial_dat, features = sc_clusters, pt.size.factor = opt$pt.size, alpha = c(1, 1), stroke = 0, ncol = 4, crop = TRUE)
print(sfp2)
dev.off()

#name4 <- paste("02.3", opt$proname, "prediction_seurat.clusters.pdf", sep = "_")
#pdf(name4, width = 16, height=24)
#pt.size <- opt$pt.size + 30
#sfp3 <- SpatialFeaturePlot(spatial_dat, features = sc_clusters, pt.size.factor = pt.size, alpha = c(0.1, 1), stroke = 0,ncol = 4, crop = TRUE)
#print(sfp3)
#dev.off()



##Based on these prediction scores, we can also predict cell types whose location is spatially restricted. 
##We use the same methods based on marked point processes to define spatially variable features, 
##but use the cell type prediction scores as the “marks” rather than gene expression.
#spatial_dat <- FindSpatiallyVariableFeatures(spatial_dat, assay = "predictions", selection.method = "markvariogram",
#    features = rownames(spatial_dat), r.metric = 5, slot = "data")
#top.clusters <- head(SpatiallyVariableFeatures(spatial_dat), 8)
#name6 <- paste("03", opt$proname, "prediction_top8.clusters.pdf", sep = "_")
#pdf(name6,width = 16, height=24)
#SpatialPlot(object = spatial_dat, features = top.clusters, ncol = 4, alpha = c(0.1, 1), stroke = 0, pt.size.factor = 16, crop = TRUE)
#dev.off()



















