library(getopt)
arg <- matrix(c("input", "i","1","character","input file1",
                "outdir","o","1","character","outdir",
                "sample","s","1","character","sample,default=Maize",
                "tissue","t","1","character","tissue,default=Embro",
                "regressall","a","1","character","regress all the effects or half",
                "cc.genes","e","1","character","input cell cycle genes list",
                "cc.colname","b","1","character","input cell cycle genes colname",
                "nC_RNA","u","1","integer"," i.e. nCount_RNA, default=1500",
                "rds","f","0","logical", "Save the RDS file",
                "dims","d","1","integer","dims option for FindNeighbors,default=15",
                "resolution","r","1","numeric","resolution option for FindClusters,[0.4-1.2],default=1",
                "minCG","m","1","integer","minimum gene number for each cell, i.e. nFeature_RNA, default=500",
                "maxCG","n","1","integer"," max gene number for each cell, i.e. nFeature_RNA, default=5000",
                "lambda","l","1","numeric"," RUNharmony lambda, default=1",
                "featurePlot","p","1","character","T or F",
                "marker.colname","k","1","character","markergene colnames",
                "features","g","1","character","plot genes expression"
                ),byrow=T,ncol=5)
opt = getopt(arg)
if (is.null(opt$sample)){
        opt$sample <- "Maize"
}
if (is.null(opt$tissue)){
        opt$tissue <- "stem"
}
if (is.null(opt$outdir)){
        opt$outdir <- "output"
}
if (is.null(opt$regressall)){
        opt$regressall <- T
}
if (is.null(opt$dims)){
        opt$dims <- 15
}
if (is.null(opt$resolution)){
        opt$resolution <- 1
}
if (is.null(opt$minCG)){
    opt$minCG <- 500
}
if (is.null(opt$maxCG)){
    opt$maxCG <- 5000
}
if (is.null(opt$lambda)){
    opt$lambda <- 1
}
if (is.null(opt$featurePlot)){
 opt$featurePlot <- F
}


library(harmony)
library(dplyr)
library(tidyr)
library(Seurat)
library(stringr)
library(patchwork)
library(ggplot2)
library(cowplot)
library(Matrix)
library(DoubletFinder)

options(future.globals.maxSize = 10000 * 1024^3)

#find the doublets
Find_doublet <- function(data){
  sweep.res.list <- paramSweep_v3(data, PCs = 1:30, sct = FALSE)
  sweep.stats <- summarizeSweep(sweep.res.list, GT = FALSE)
  bcmvn <- find.pK(sweep.stats)
  nExp_poi <- round(0.05*ncol(data))
  p<-as.numeric(as.vector(bcmvn[bcmvn$MeanBC==max(bcmvn$MeanBC),]$pK))
  data <- doubletFinder_v3(data, PCs = 1:30, pN = 0.25, pK = p, nExp = nExp_poi, reuse.pANN = FALSE, sct = FALSE)
  colnames(data@meta.data)[ncol(data@meta.data)] = "doublet_info"
  data<-subset(data,subset=doublet_info=="Singlet")
  data
}

file <- readLines(opt$input)

setwd(opt$outdir);
rdslist<-list()
plot.list<-list()
n=0
id=c()

for(i in 1:length(file))
{
#loading data
print("loading data")
matrix_dir=file[i]
print(matrix_dir)
mat <- Read10X(matrix_dir,gene.column=1)
thedata<- CreateSeuratObject(counts = mat, assay = "RNA", min.cells = 3, project = opt$sample, min.features = 200)
print(thedata)
    thedata <- subset(thedata, subset = nFeature_RNA > opt$minCG & nFeature_RNA < opt$maxCG)
print(thedata)

##add meta.data
  print("add meta.data")
  name1 <- strsplit(file[i],"/",fixed=T)[[1]][length(strsplit(file[i],"/",fixed=T)[[1]])-1]
  name2 <- gsub("_\\d.*web_.*","",name1)
  thedata@meta.data$batch <- name1
  thedata@meta.data$group <- name2

##find the doublecell
  thedata <- NormalizeData(thedata, verbose = F)
  thedata <- FindVariableFeatures(thedata, selection.method = "vst", nfeatures = 2000, verbose = F)
  thedata <- ScaleData(thedata, verbose = F)
  thedata <- RunPCA(thedata, verbose = F)
  thedata <- RunUMAP(thedata, dims = 1:30, verbose = F)
  thedata <- Find_doublet(thedata)
     
#remove the bad data of sample
  if(length(colnames(thedata)) > 100){
    n=n+1
    rdslist[[n]] <- thedata
    id[n]<- name1
    plot1 <- VlnPlot(thedata, features = c("nFeature_RNA", "nCount_RNA"))
    plot.list[[n]] <- plot1
    print(paste0(matrix_dir,": good data"))
    } else {print(paste0(matrix_dir,": bad data"))}

}

pdf("01.genes_UMIcounts.plot.pdf")
plot.list
dev.off()


#Runharmony
print("merge")
data.merge <- merge(rdslist[[1]], y=rdslist[-1],add.cell.ids = id)
print("Normalization")
data.merge <- NormalizeData(data.merge, normalization.method = "LogNormalize", scale.factor = 10000, verbose = F)
print("FindVariableFeatures")
data.merge <- FindVariableFeatures(data.merge, selection.method = "vst", nfeatures = 3000, verbose = F)
#print("ScaleDate")
#data.merge <- ScaleData(data.merge, features = rownames(data.merge), verbose = F)

pdf("01.2.genes_UMIcounts.plot.pdf")
VlnPlot(data.merge, features = c("nFeature_RNA", "nCount_RNA"))
dev.off()



### cell cycle
if(nchar(opt$cc.genes) > 0){
 
 
 cc.col <- opt$cc.colname
 cc.genes <- read.csv(opt$cc.genes, header = T)
 s.genes <- cc.genes[which(cc.genes[,1]=="S"), cc.col]
 s.genes <- unique(unlist(strsplit(s.genes, ",")))
 g2m.genes <- cc.genes[which(cc.genes[,1] =="G2M"), cc.col]
 g2m.genes <- unique(unlist(strsplit(g2m.genes, ",")))
 data.merge <- CellCycleScoring(data.merge, s.features = s.genes, g2m.features = g2m.genes, set.ident = T)

##remove effects of cell cycle genes or not 
  if(opt$regressall){
    #Regress out cell cycle scores during data scaling
    data.merge <- ScaleData(data.merge, vars.to.regress = c("S.Score", "G2M.Score"), features = rownames(data.merge))
  } else {
    data.merge$CC.Difference <- data.merge$S.Score - data.merge$G2M.Score
    data.merge <- ScaleData(data.merge, vars.to.regress = "CC.Difference", features = rownames(data.merge))
  }
  data.merge <- RunPCA(data.merge, features = VariableFeatures(data.merge), nfeatures.print = 10)
  # When running a PCA on only cell cycle genes, cells no longer separate by cell-cycle phase
  #data.harmony <- RunPCA(data.harmony, features = c(s.genes, g2m.genes))
  #DimPlot(data.harmony)
} else {
  data.merge <- RunPCA(data.merge, npcs = 30, verbose = FALSE)
}

data.harmony <- RunHarmony(data.merge, 'batch', plot_convergenc=TRUE,lambda = opt$lambda)
pdf("02_ElbowPlot.pdf", width = 10)
ElbowPlot(object = data.harmony)
dev.off()

data.harmony <- RunUMAP(data.harmony, reduction = "harmony", dims = 1:opt$dims)
data.harmony <- FindNeighbors(data.harmony, reduction = "harmony", dims = 1:opt$dims)
data.harmony <- FindClusters(data.harmony, resolution = opt$resolution)
saveRDS(data.harmony,"data.cc.RDS")

if(nchar(opt$cc.genes) > 0){
  pdf("03_cc_umap.cell.stage.pdf", height = 8, width = 16)
  DimPlot(data.harmony, reduction = "umap", group.by = c("Phase","seurat_clusters"),pt.size = 0.5, label = TRUE, repel = TRUE)
  dev.off()
}


pdf("03_umap.harmony.pdf", height = 8, width =16 )
plot1 <- DimPlot(object = data.harmony, reduction = "umap", label = T, pt.size=0.5, group.by = "seurat_clusters")
plot1.1 <- FeaturePlot(data.harmony, features = "nFeature_RNA", reduction = "umap", label = T, combine = F, order = T)
plot1.2 <- DimPlot(object = data.harmony, reduction = "umap", label = T,pt.size=0.5,group.by = "doublet_info")
plot1
plot1.1
plot1.2
dev.off()

pdf("05.cell_number.pdf", width = 12, height = 8)
dat<-as.data.frame(table(data.harmony@active.ident))
p<-ggplot(dat,aes(Var1,Freq,fill=Var1))+geom_bar(stat = "identity",position = "dodge") + geom_text(aes(label=Freq,vjust=-0.5) )
p
dev.off()
#write.table(dat,file = "05.cell_number.txt",sep="\t",quote=F,row.names = F)

###all marker genes
#DefaultAssay(data.harmony) <- "RNA"
adata.markers <- FindAllMarkers(data.harmony, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
allmakers <- adata.markers %>% group_by(cluster)
write.csv(allmakers, "06.markergenes_list.csv")

###top10 marker genes heatmap
pdf('06.top10_markergenes.heatmap.pdf',width = 8 , height = 8 )
if("avg_log2FC" %in% colnames(adata.markers)){
top10 <- adata.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
}else{top10 <- adata.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_logFC)}
DoHeatmap(data.harmony, features = top10$gene)
dev.off()

fplot1 <- c()
heatmap <- c()
DefaultAssay(data.harmony) <- "RNA"
if(nchar(opt$features)>0){
  features <- read.csv(opt$features,header = T)
  col <- opt$marker.colname
  genes <- features[,col]
  genes <- unique(unlist(strsplit(genes, ",")))
  genes <- unique(unlist(strsplit(genes, " ")))
 # for(i in 1:length(genes)){genes[i] <- paste(genes,".v3.2")}
  genes <- genes[which(genes%in%rownames(data.harmony))]
  
  h <- length(genes)/5
  pdf("07.cc.input.feature.heatmap.pdf",width = 20, height = h)
  heatmap <- DoHeatmap(data.harmony, features = genes, slot = "scale.data",)
  print(heatmap)
  dev.off()
  
  pdf("07.cc.input.featurePlot.pdf")
  fplot1 <- FeaturePlot(data.harmony, features = genes, slot = "scale.data",label = T, combine = F, order = T)
  print(fplot1)
  dev.off()
}































